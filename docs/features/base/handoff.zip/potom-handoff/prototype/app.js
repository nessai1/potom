const $ = (s,r=document)=>r.querySelector(s);
const $$ = (s,r=document)=>[...r.querySelectorAll(s)];
const icon = (name,cls='')=>`<svg class="icon ${cls}" aria-hidden="true"><use href="#i-${name}"/></svg>`;
const esc = s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const today = new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Kaliningrad',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const parseDate = s=>new Date(s+'T12:00:00');
const dateKey = d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const offsetDate=n=>{const d=parseDate(today);d.setDate(d.getDate()+n);return dateKey(d)};
const dayDiff=s=>s?Math.round((parseDate(s)-parseDate(today))/86400000):null;
const ruDay=(n,forms=['день','дня','дней'])=>forms[Math.abs(n)%100>10&&Math.abs(n)%100<20?2:Math.abs(n)%10===1?0:[2,3,4].includes(Math.abs(n)%10)?1:2];
const shortDate=s=>s?parseDate(s).toLocaleDateString('ru-RU',{day:'numeric',month:'short'}).replace('.',''):'Срока нет';
const statusNames={created:'Создана',progress:'Выполняется',deferred:'Отложено',done:'Выполнено'};
const statusColors={created:'gray',progress:'pink',deferred:'yellow',done:'green'};
const initialProjects=[{id:'design',name:'Дизайн-проект',color:'#dba4bd'},{id:'work',name:'Рабочие будни',color:'#d8c375'},{id:'personal',name:'Для себя',color:'#a5b39c'}];
const initialTasks=[
 {id:1,title:'Собрать дизайн-систему',project:'design',status:'progress',due:offsetDate(2),priority:'high',description:'Собрать всё в одном месте, чтобы больше не искать **тот самый оттенок розового**.\n\nНачать с базовых компонентов и оставить место для маленьких радостей. [Референсы в Figma](https://www.figma.com/)',checklist:[{text:'Собрать цветовую палитру',done:true},{text:'Определить типографику',done:true},{text:'Нарисовать базовые иконки',done:true},{text:'Подготовить компоненты',done:false},{text:'Описать состояния элементов',done:false}],notes:[{id:1,text:'**Мысль на потом**\nНе забыть про тёмную тему. Но сначала — светлая сторона жизни.',date:today}],created:offsetDate(-3)},
 {id:2,title:'Подготовить макеты для разработки',project:'design',status:'progress',due:offsetDate(1),priority:'high',description:'Собрать ключевые экраны, проверить отступы и передать макеты разработчикам. **Красиво — это когда понятно.**',checklist:[{text:'Проверить главный экран',done:true},{text:'Подготовить состояния',done:false},{text:'Собрать адаптивы',done:false},{text:'Передать в разработку',done:false}],notes:[],created:offsetDate(-2)},
 {id:3,title:'Придумать пустые состояния',project:'design',status:'created',due:offsetDate(4),priority:'normal',description:'Пустой экран — тоже часть продукта. Пусть он будет дружелюбным и подсказывает следующий шаг.',checklist:[{text:'Список без задач',done:false},{text:'Поиск без результатов',done:false},{text:'Первый запуск',done:false}],notes:[],created:offsetDate(-1)},
 {id:4,title:'Тёмная тема. Когда-нибудь.',project:'design',status:'deferred',due:'',priority:'low',description:'Для полуночников, сов и тех, кто просто любит тёмную сторону. **Пусть идея настоится.**',checklist:[{text:'Подобрать палитру',done:false},{text:'Проверить контраст',done:false}],notes:[],created:offsetDate(-1)},
 {id:5,title:'Разобрать входящие',project:'work',status:'progress',due:offsetDate(0),priority:'normal',description:'Каждому письму — ответ, каждой идее — своё место. Кофе тоже считается инструментом продуктивности.',checklist:[{text:'Ответить команде',done:true},{text:'Проверить документы',done:true},{text:'Разобрать остальные письма',done:false}],notes:[],created:offsetDate(-2)},
 {id:6,title:'Отправить еженедельный отчёт',project:'work',status:'created',due:offsetDate(-1),priority:'high',description:'Коротко рассказать, что получилось на этой неделе и что планируем дальше.',checklist:[{text:'Собрать результаты',done:true},{text:'Написать выводы',done:false},{text:'Отправить отчёт',done:false}],notes:[],created:offsetDate(-4)},
 {id:7,title:'Спланировать следующую неделю',project:'work',status:'created',due:offsetDate(5),priority:'normal',description:'Выбрать три главных дела. Оставить время на жизнь и внезапные прекрасные идеи.',checklist:[{text:'Собрать задачи',done:false},{text:'Расставить приоритеты',done:false}],notes:[],created:today},
 {id:8,title:'Дочитать ту самую книгу',project:'personal',status:'created',due:offsetDate(3),priority:'low',description:'Ещё несколько глав. Телефон — в сторону, чай — поближе.',checklist:[{text:'Глава 7',done:true},{text:'Глава 8',done:true},{text:'Глава 9',done:false},{text:'Эпилог',done:false}],notes:[],created:offsetDate(-7)},
 {id:9,title:'Выучить итальянский. Ну хотя бы ciao',project:'personal',status:'deferred',due:'',priority:'low',description:'Начать с малого. **Ciao** уже считается.',checklist:[{text:'Выбрать приложение',done:false},{text:'Выучить первые 10 слов',done:false}],notes:[],created:offsetDate(-5)},
 {id:10,title:'Собрать первые референсы',project:'design',status:'done',due:offsetDate(-2),priority:'normal',description:'Сохранить всё, что вдохновляет.',checklist:[{text:'Найти референсы',done:true},{text:'Собрать мудборд',done:true}],notes:[],created:offsetDate(-6)},
 {id:11,title:'Разобрать рабочий стол',project:'personal',status:'done',due:offsetDate(-3),priority:'normal',description:'Немного порядка снаружи — немного спокойствия внутри.',checklist:[{text:'Удалить лишнее',done:true},{text:'Разложить по папкам',done:true}],notes:[],created:offsetDate(-5)},
 {id:12,title:'Согласовать план проекта',project:'work',status:'done',due:offsetDate(-1),priority:'normal',description:'У всех есть план. Теперь общий.',checklist:[{text:'Подготовить план',done:true},{text:'Обсудить с командой',done:true}],notes:[],created:offsetDate(-4)}
];
const legacyTemplates=JSON.parse(JSON.stringify(initialTasks));
const analystTitles=["Вытащить требования из «ну ты поняла»", "Добить критерии приёмки", "Разобрать, что бизнес имел в виду", "Переписать ТЗ. Когда рак согласует", "Запротоколировать очередной созвон", "Отправить отчёт, пока не закопали", "Разгрести бэклог после «маленьких правок»", "Записаться к стоматологу, блин", "Выучить слово «нет». Применить к скоупу", "Согласовать границы первой версии", "Закрыть вкладки с прошлой жизни", "Описать статусы заявки"];
const analystDescriptions=["Бизнес сказал: **«Сделайте как обычно, только по-другому»**. Выяснить, что конкретно должно работать, кто этим пользуется и какого чёрта это опять на вчера.\n\n## Критерии приёмки\n\n- Сценарий записан человеческим языком.\n- Все спорные переходы согласованы.\n- На вопросы есть ответы, а не «ну ты поняла».", "Проверить, что каждый критерий можно проверить. **«Чтоб нормально»** не проходит, даже если написать капсом.", "Отделить реальные требования от фразы «а давайте ещё вот это». Приложить пруфы.", "Третья финальная версия уже была. У этой будет нормальный номер.", "Зафиксировать решения, пока у коллег не обновилась память.", "Цифры приложить. Магию роста объяснить. Не плакать в диаграмму.", "Декомпозировать внезапное «там всего пара изменений». Спойлер: нет.", "Один созвон, на котором правда будут сверлить.", "Границы проекта не выставят себя сами. Начать хотя бы с одной фразы.", "Скоуп согласован. Скриншоты сохранены. Переобувание будет платным.", "Семнадцать вкладок «потом прочитаю» ушли в историю.", "Теперь слово «готово» у всех означает примерно одно и то же."];
const analystChecks=[["Собрать хотелки бизнеса", "Найти владельца процесса", "Описать основной сценарий", "Зафиксировать исключения", "Получить человеческое согласование"], ["Проверить сценарии", "Описать ошибки", "Уточнить ограничения", "Согласовать критерии"], ["Разобрать переписку", "Собрать вопросы", "Выбить ответы"], ["Сверить версии", "Не назвать файл final_final"], ["Записать решения", "Назначить ответственных", "Отправить протокол"], ["Собрать цифры", "Написать выводы", "Отправить отчёт"], ["Собрать правки", "Отделить скоуп-крип"], ["Найти клинику", "Выбрать дату", "Записаться", "Сходить"], ["Отрепетировать «нет»", "Не извиниться после"], ["Собрать границы", "Согласовать"], ["Закрыть вкладки", "Сохранить нужное"], ["Описать статусы", "Согласовать переходы"]];
const analystDocument="# Требования без телепатии\n\n> «Ну ты же аналитик, сама поймёшь» — не источник требований.\n\n## Что вообще происходит\n\nБизнесу нужен единый сценарий согласования заявки. Сейчас каждый отдел понимает слово «согласовано» по-своему. Отсюда три таблицы, два чата и одна слегка дёргающаяся аналитичка.\n\n**Цель:** описать процесс так, чтобы разработка не занималась гаданием по скриншоту.\n\n## Критерии приёмки\n\n- Пользователь видит актуальный статус заявки.\n- При отказе причина обязательна. «Потому что» не считается.\n- Повторное согласование сохраняет предыдущую историю.\n- Уведомление приходит один раз, а не до нервного тика.\n\n## Статусы и переходы\n\n| Статус | Кто меняет | Что происходит |\n| --- | --- | --- |\n| Черновик | Автор | Можно редактировать |\n| На согласовании | Автор | Изменения заблокированы |\n| Нужны правки | Согласующий | Причина обязательна |\n| Согласовано | Согласующий | Фиксируем версию |\n\n## Вопросы к бизнесу\n\n1. Что делаем, если согласующий в отпуске?\n2. Может ли автор согласовать сам себе? Хочется верить, что нет.\n3. Кто отвечает за заявку после изменения оргструктуры?\n\n**Решение после созвона:** автосогласование убираем из первой версии. Это отдельная задача, а не «ну там одна галочка».\n\n## Проверка данных\n\n```sql\nSELECT status, COUNT(*) AS total\nFROM requests\nGROUP BY status;\n```\n\n## Ссылки и договорённости\n\n- [Документация PostgreSQL](https://www.postgresql.org/docs/)\n- [Пример описания API](https://spec.openapis.org/oas/latest.html)\n\n---\n\n### Чтобы потом не переобувались\n\nОбъём первой версии согласован: форма, статусы, история и уведомления. Экспорт в Excel обсуждаем отдельно. Нельзя одновременно «ничего не менять» и «сделать вообще по-другому». Хотя бизнес, конечно, попробует.\n";
initialProjects[0].name='Аналитический ад';initialProjects[1].name='Бизнес хочет';initialProjects[2].name='Жизнь вне созвона';
initialTasks.forEach((t,i)=>{t.title=analystTitles[i];t.description=analystDescriptions[i];t.checklist=t.checklist.map((c,j)=>({...c,text:analystChecks[i][j]||c.text}));if(i===0)t.notes=[{id:1,text:analystDocument,date:today}];});

let stored=null;try{stored=JSON.parse(localStorage.getItem('potom-ui-v1'))}catch{}
let data=stored?.tasks?stored:{tasks:initialTasks,projects:initialProjects,unlocked:['first','done','markdown']};
if(data.schema!==2){
 data.tasks.forEach(t=>{const old=legacyTemplates.find(x=>x.id===t.id),fresh=initialTasks.find(x=>x.id===t.id);if(!old||!fresh)return;if(t.title===old.title)t.title=fresh.title;if(t.description===old.description)t.description=fresh.description;if(JSON.stringify(t.checklist)===JSON.stringify(old.checklist))t.checklist=fresh.checklist;if(JSON.stringify(t.notes)===JSON.stringify(old.notes))t.notes=fresh.notes;});
 data.projects.forEach(p=>{const old={design:'Дизайн-проект',work:'Рабочие будни',personal:'Для себя'}[p.id];if(p.name===old)p.name=initialProjects.find(x=>x.id===p.id).name;});data.schema=2;
}
data.metrics=data.metrics||{};data.settings=data.settings||{theme:'light'};
let view='list',selectedId=null,tab='all',groupBy='project',projectFilter='',onlyUrgent=false,search='',collapsed=new Set(),calendarMonth=parseDate(today),selectedDay=today,editorState=null,detailExpanded=false,toastTimer;
const save=()=>{try{localStorage.setItem('potom-ui-v1',JSON.stringify(data))}catch{};$('.sidebar-footer').innerHTML=`<span class="online-dot"></span> Все изменения сохранены ${icon('help')}`};
const getTask=id=>data.tasks.find(t=>t.id===Number(id));
const getProject=id=>data.projects.find(p=>p.id===id)||data.projects[0];
const doneCount=t=>t.checklist.filter(c=>c.done).length;
const percent=t=>t.checklist.length?Math.round(doneCount(t)/t.checklist.length*100):0;
const activeTasks=()=>data.tasks.filter(t=>t.status==='progress');
function toast(message){$('#toast').textContent=message;$('#toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),3000)}
function unlock(id){if(!achievements.some(a=>a.id===id))return;if(!data.unlocked.includes(id)){data.unlocked.push(id);save();setTimeout(()=>toast('✦ Новая ачивка: '+achievements.find(a=>a.id===id)?.title),200)}}
function renderMarkdown(value){return markdownToHtml(value)}
function badge(t){return `<span class="badge ${statusColors[t.status]}"><span class="status-dot"></span>${statusNames[t.status]}</span>`}
function taskProgress(t){return `<div class="task-progress"><div class="progress-title"><span>${doneCount(t)}/${t.checklist.length}</span><span>${percent(t)}%</span></div><div class="progress-track"><div class="progress-fill ${percent(t)===100?'complete':''}" style="width:${percent(t)}%"></div></div></div>`}
function deadlineLabel(t){const d=dayDiff(t.due);return `<div class="deadline ${d!==null&&d<0&&t.status!=='done'?'overdue':d!==null&&d<=2&&t.status!=='done'?'near':''}">${d!==null&&d<=1&&t.status!=='done'?icon('clock'):''}${!t.due?'Срока нет':d===0?'Сегодня':d===1?'Завтра':shortDate(t.due)}<small>${!t.due?'дата не назначена':t.status==='done'?'готово ✓':d<0?'просрочено':d===0?'тот самый день':d===1?'уже совсем скоро':`через ${d} ${ruDay(d)}`}</small></div>`}
function renderNav(){
 $('#nav-task-count').textContent=data.tasks.filter(t=>t.status!=='done').length;
 $('#active-count').textContent=activeTasks().length;
 $('.nav-achievement').textContent=`${data.unlocked.length}/${achievements.length}`;
 $$('.nav-item[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
 $('#breadcrumb-current').textContent={list:'Мои задачи',board:'Канбан',calendar:'Календарь',achievements:'Достижения'}[view];
 $('#projects').innerHTML=data.projects.map(p=>`<button class="project-item ${projectFilter===p.id?'chosen':''}" data-project="${p.id}"><span class="project-dot" style="background:${p.color}"></span><span>${esc(p.name)}</span><small>${data.tasks.filter(t=>t.project===p.id&&t.status!=='done').length}</small></button>`).join('');
 $$('#projects button').forEach(b=>b.onclick=()=>{projectFilter=projectFilter===b.dataset.project?'':b.dataset.project;view='list';render()});
 renderActivePopover();
}
function renderActivePopover(){
 const tasks=activeTasks();$('#active-popover').innerHTML=`<div class="popover-head">Сейчас в работе <small>${tasks.length} ${ruDay(tasks.length,['задача','задачи','задач'])}</small></div>${tasks.length?tasks.map(t=>`<button class="popover-task" data-open="${t.id}"><span class="pulse-dot"></span><span><b>${esc(t.title)}</b><small>${esc(getProject(t.project).name)} · ${percent(t)}% готово</small></span></button>`).join(''):'<p class="empty" style="padding:20px 0">В работе пусто. Не говори об этом менеджеру.</p>'}<div class="popover-footer">Взяла три задачи. Все три взяли тебя.</div>`;
 $$('[data-open]',$('#active-popover')).forEach(b=>b.onclick=()=>openTask(b.dataset.open));
}
function pageTop(title,subtitle,button=true){return `<div class="page-top"><div><h1>${title}</h1><p>${subtitle}</p></div>${button?`<button class="primary-btn" data-new>${icon('plus')}Новая задача</button>`:''}</div>`}
function filteredTasks(){return data.tasks.filter(t=>(!projectFilter||t.project===projectFilter)&&(!search||`${t.title} ${t.description} ${getProject(t.project).name}`.toLowerCase().includes(search.toLowerCase()))&&(view!=='list'||tab==='done'||!onlyUrgent||(t.due&&dayDiff(t.due)<=2&&t.status!=='done')))}
function renderList(){
 const all=filteredTasks(),open=all.filter(t=>t.status!=='done');
 let tasks=all.filter(t=>tab==='done'?t.status==='done':t.status!=='done'&&(tab==='today'?t.due===today:tab==='soon'?t.due&&dayDiff(t.due)>=0&&dayDiff(t.due)<=2:true));
 const project=projectFilter?getProject(projectFilter):null;
 let html=pageTop(project?esc(project.name):'Мои задачи','Требования меняются. <span class="greeting">Скриншоты остаются.</span>');
 html+=`<div class="summary"><div class="summary-item"><b>${open.length}</b> всего задач</div><div class="summary-item"><span class="mini-dot"></span><b>${open.filter(t=>t.status==='progress').length}</b> в работе</div><div class="summary-item"><span class="mini-dot"></span><b>${open.filter(t=>t.due&&dayDiff(t.due)<=2).length}</b> скоро дедлайн</div><div class="summary-item"><span class="mini-dot"></span><b>${all.filter(t=>t.status==='done').length}</b> готово</div></div>`;
 html+=`<div class="view-toolbar"><div class="tabs">${[['all','Все задачи',open.length],['today','Сегодня',open.filter(t=>t.due===today).length],['soon','Скоро',open.filter(t=>t.due&&dayDiff(t.due)>=0&&dayDiff(t.due)<=2).length],['done','Готово',all.filter(t=>t.status==='done').length]].map(([id,label,count])=>`<button class="tab ${tab===id?'active':''}" data-tab="${id}">${label}<span>${count}</span></button>`).join('')}</div><div class="toolbar-controls"><label class="group-select" title="Сгруппировать задачи">${icon('group')}<select id="group-by" aria-label="Группировка"><option value="project" ${groupBy==='project'?'selected':''}>По проектам</option><option value="status" ${groupBy==='status'?'selected':''}>По статусу</option><option value="due" ${groupBy==='due'?'selected':''}>По сроку</option><option value="none" ${groupBy==='none'?'selected':''}>Без групп</option></select></label><button class="icon-btn filter-button ${onlyUrgent?'active':''}" id="filter-urgent" title="Показать только близкие сроки" aria-label="Фильтр близких сроков" aria-pressed="${onlyUrgent}">${icon('sliders')}</button></div></div>`;
 html+=`<div class="list-col-head"><span>НАЗВАНИЕ ЗАДАЧИ</span><span>ПРОГРЕСС</span><span>КРАЙНИЙ СРОК</span></div>`;
 const groups=[];
 if(groupBy==='project')data.projects.forEach(p=>groups.push({key:p.id,title:p.name,color:p.color,tasks:tasks.filter(t=>t.project===p.id)}));
 else if(groupBy==='status')Object.entries(statusNames).forEach(([k,v])=>groups.push({key:k,title:v,color:{created:'#b5afa4',progress:'#dba4bd',deferred:'#d8c375',done:'#a5b39c'}[k],tasks:tasks.filter(t=>t.status===k)}));
 else if(groupBy==='due') [{key:'late',title:'Срок уже прошёл',color:'#d4a2a2',fn:t=>t.due&&dayDiff(t.due)<0},{key:'close',title:'На носу',color:'#d8c375',fn:t=>t.due&&dayDiff(t.due)>=0&&dayDiff(t.due)<=2},{key:'later',title:'Впереди есть время',color:'#a5b39c',fn:t=>t.due&&dayDiff(t.due)>2},{key:'someday',title:'Когда-нибудь',color:'#bab1c6',fn:t=>!t.due}].forEach(g=>groups.push({...g,tasks:tasks.filter(g.fn)}));
 else groups.push({key:'all',title:'Все задачи',color:'#dba4bd',tasks});
 html+=groups.filter(g=>g.tasks.length).map(g=>`<section class="task-group"><div class="group-header ${collapsed.has(g.key)?'collapsed':''}"><button data-collapse="${g.key}">${icon('down')}<span class="project-dot" style="background:${g.color}"></span>${esc(g.title)}<small>${g.tasks.length}</small></button><button class="icon-btn" data-new ${groupBy==='project'?`data-new-project="${g.key}"`:''} aria-label="Добавить задачу в ${esc(g.title)}">${icon('plus')}</button></div>${collapsed.has(g.key)?'':g.tasks.map(taskRow).join('')}${collapsed.has(g.key)?'':`<button class="task-add" data-new ${groupBy==='project'?`data-new-project="${g.key}"`:''}>${icon('plus')}Добавить задачу</button>`}</section>`).join('');
 if(!tasks.length)html+=`<div class="empty"><span class="empty-icon">${catSvg(search?'chaos':'sleep','empty-cat')}</span>${search?'Ничего не нашлось. Попробуем иначе?':tab==='done'?'Пока ничего не закрыто. Бизнес зато уже открыл рот.':tab==='today'?'Сегодня ничего не горит. Не обновляй почту.':'Пусто. Либо всё сделала, либо забыла записать.'}</div>`;
 html+=`<div class="list-footnote">${icon('spark')} «Просто добавьте поле» — и другие начала катастрофы.</div>`;
 $('#main').innerHTML=html;
 $$('[data-tab]').forEach(b=>b.onclick=()=>{tab=b.dataset.tab;if(tab==='done')onlyUrgent=false;renderMain()});
 $('#group-by').onchange=e=>{groupBy=e.target.value;collapsed.clear();renderMain()};
 $('#filter-urgent').onclick=()=>{onlyUrgent=!onlyUrgent;renderMain()};
 $$('[data-collapse]').forEach(b=>b.onclick=()=>{const k=b.dataset.collapse;collapsed.has(k)?collapsed.delete(k):collapsed.add(k);renderMain()});
 bindTaskActions();
}
function taskRow(t){return `<article class="task-row ${selectedId===t.id?'selected':''} ${t.due&&dayDiff(t.due)<=2&&t.status!=='done'?'urgent':''} ${t.status==='done'?'completed':''}" data-task="${t.id}" tabindex="0" role="button" aria-label="Открыть задачу ${esc(t.title)}"><div class="task-name"><button class="task-complete ${t.status==='done'?'done':''}" data-complete="${t.id}" aria-label="${t.status==='done'?'Вернуть задачу в работу':'Завершить задачу'}">${t.status==='done'?icon('check'):''}</button><div><div class="task-title">${esc(t.title)}</div><div class="task-meta"><span class="task-id">PT–${String(t.id).padStart(3,'0')}</span>${badge(t)}${t.priority==='high'?`<span class="task-priority">${icon('flag')}Важно</span>`:''}</div></div></div>${taskProgress(t)}${deadlineLabel(t)}</article>`}
function bindTaskActions(){
 $$('[data-task]').forEach(el=>{el.onclick=()=>openTask(el.dataset.task);el.onkeydown=e=>{if(e.target!==el)return;if(e.key==='Enter'||e.key===' '){e.preventDefault();openTask(el.dataset.task)}}});
 $$('[data-complete]').forEach(b=>b.onclick=e=>{e.stopPropagation();completeTask(b.dataset.complete)});
 $$('[data-new]').forEach(b=>b.onclick=()=>newTaskModal(b.dataset.newProject));
}

function changeStatus(t,status){
 const previous=t.status;t.status=status;if(previous==='deferred'&&status==='progress')recordEvent('revived');
 if(status==='done'){if(previous!=='done')t.completedAt=today;t.checklist.forEach(c=>c.done=true);unlock('done');if(t.due===today){recordEvent('onTime');unlock('train')}if(t.due&&dayDiff(t.due)<0){recordEvent('lateDone');unlock('overdue_done')}if(t.checklist.length>=5)unlock('clean');if(data.tasks.filter(x=>x.status==='done'&&x.completedAt===today).length>=5)unlock('fire');if(data.tasks.length>=3&&data.tasks.every(x=>x.status==='done'))unlock('free')}
 else{delete t.completedAt;if(status==='deferred'){t.due='';recordEvent('deferred');unlock('aged')}}
}
function completeTask(id){const t=getTask(id),was=t.status==='done';changeStatus(t,was?'created':'done');save();render();toast(was?'Задача снова в списке':'Одна херня закрыта. Несите следующую.')}
function renderBoard(){
 const tasks=filteredTasks();
 $('#main').innerHTML=pageTop('Доска разруливания','От «там на пять минут» до «слава богу, закрыла».')+`<div class="board-toolbar"><p>Двигай карточки. Пусть хоть что-нибудь двигается.</p><button class="secondary-btn" id="show-board-done">${icon('check')}Готово <span>${data.tasks.filter(t=>t.status==='done').length}</span></button></div><div class="board">${[['created','Созданы'],['progress','Выполняется'],['deferred','Отложено'],['done','Выполнено']].map(([status,label])=>`<section class="kanban-col" data-drop="${status}"><div class="kanban-heading"><span class="status-dot"></span>${label}<small>${tasks.filter(t=>t.status===status).length}</small><button class="icon-btn" data-new-status="${status}" aria-label="Добавить задачу">${icon('plus')}</button></div>${tasks.filter(t=>t.status===status).map(t=>`<article class="kanban-card ${t.due&&dayDiff(t.due)<=2&&t.status!=='done'?'urgent':t.status==='done'?'card-done':''}" draggable="true" data-drag="${t.id}" data-task="${t.id}" tabindex="0" role="button" aria-label="Открыть ${esc(t.title)}"><span class="task-id">${t.status==='done'?'✓ ':''}PT–${String(t.id).padStart(3,'0')}</span><h3>${esc(t.title)}</h3><span class="kanban-project"><span class="project-dot" style="background:${getProject(t.project).color};height:5px;width:5px"></span>${esc(getProject(t.project).name)}</span><div class="progress-track"><div class="progress-fill ${t.status==='done'?'complete':''}" style="width:${percent(t)}%"></div></div><div class="kanban-card-footer"><span>${icon('list')}${doneCount(t)}/${t.checklist.length}</span><span>${t.due?icon('calendar')+shortDate(t.due):'Срока нет'}</span></div></article>`).join('')}<button class="kanban-add" data-new-status="${status}">${icon('plus')}Добавить задачу</button></section>`).join('')}</div><div class="list-footnote">${icon('spark')} «Выполнено» — красивое слово. Особенно в пятницу.</div>`;
 bindTaskActions();
 $('#show-board-done').onclick=()=>{view='list';tab='done';render()};
 $$('[data-new-status]').forEach(b=>b.onclick=()=>newTaskModal(null,b.dataset.newStatus));
 $$('[data-drag]').forEach(c=>{c.ondragstart=e=>{e.dataTransfer.setData('text/plain',c.dataset.drag);e.dataTransfer.effectAllowed='move';setTimeout(()=>c.style.opacity='.4',0)};c.ondragend=()=>c.style.opacity='1'});
 $$('[data-drop]').forEach(col=>{col.ondragover=e=>{e.preventDefault();col.classList.add('dragover')};col.ondragleave=e=>{if(!col.contains(e.relatedTarget))col.classList.remove('dragover')};col.ondrop=e=>{e.preventDefault();const t=getTask(e.dataTransfer.getData('text/plain'));if(t){if(t.status!==col.dataset.drop){changeStatus(t,col.dataset.drop);recordEvent('boardMove')}save();render();toast('Задача перемещена: '+statusNames[t.status])}}});
}
const achievements=[
  {
    "id": "first",
    "icon": "🪳",
    "title": "Развела сущностей",
    "description": "Создать первую задачу. До тебя этой проблемы хотя бы не было в списке.",
    "category": "Задачи",
    "goal": 1
  },
  {
    "id": "done",
    "icon": "🪦",
    "title": "Одной хернёй меньше",
    "description": "Перевести первую задачу в «Выполнено». Минута молчания по её правкам.",
    "category": "Задачи",
    "goal": 1
  },
  {
    "id": "fire",
    "icon": "🧯",
    "title": "Пять жоп за один присест",
    "description": "Выполнить 5 задач за один день. МЧС просит оставить им хоть что-нибудь.",
    "category": "Задачи",
    "goal": 5
  },
  {
    "id": "free",
    "icon": "🖕",
    "title": "Бэклог, соси",
    "description": "Выполнить все задачи, когда в списке их не меньше трёх. Сейчас главное — случайно не спросить, чем ещё помочь.",
    "category": "Задачи",
    "goal": 1
  },
  {
    "id": "requirements",
    "icon": "🔮",
    "title": "Я вам не Ванга, блядь",
    "description": "Написать описание задачи длиной от 500 символов. Телепатия из требований наконец исключена.",
    "category": "Требования",
    "goal": 500
  },
  {
    "id": "final_final",
    "icon": "🪆",
    "title": "ТЗ_final_ЕБАНЫЙ_ФИНАЛ",
    "description": "Изменить описание одной задачи 5 раз. Каждая версия последняя. Все пятеро клянутся.",
    "category": "Требования",
    "goal": 5
  },
  {
    "id": "criteria",
    "icon": "⚖️",
    "title": "«Чтоб красиво» — не критерий",
    "description": "Добавить в описание заголовок «Критерии приёмки» и список из 3 пунктов. Красиво теперь измеряется, сука.",
    "category": "Требования",
    "goal": 3
  },
  {
    "id": "evidence",
    "icon": "🧾",
    "title": "На случай «я такого не говорил»",
    "description": "Добавить в одну задачу 3 Markdown-ссылки. Показания приложены, переобувочная закрыта.",
    "category": "Требования",
    "goal": 3
  },
  {
    "id": "decomposition",
    "icon": "🥩",
    "title": "Декомпозировала до фарша",
    "description": "Добавить в одну задачу 10 пунктов чеклиста. Слон больше не опознаётся.",
    "category": "Чеклисты",
    "goal": 10
  },
  {
    "id": "clean",
    "icon": "✅",
    "title": "Каждую срань — под галочку",
    "description": "Выполнить целиком чеклист минимум из 5 пунктов. Даже тот пункт, который добавила сама себе со зла.",
    "category": "Чеклисты",
    "goal": 5
  },
  {
    "id": "checklist_spree",
    "icon": "🧨",
    "title": "Галочки летели, как увольнения",
    "description": "Отметить выполненными 20 пунктов чеклистов. Отдел паники понёс невосполнимые потери.",
    "category": "Чеклисты",
    "goal": 20
  },
  {
    "id": "checklist_return",
    "icon": "🧟",
    "title": "Вы чё, опять живые?",
    "description": "Снять галочку с выполненного пункта и выполнить его снова. Требования успешно воскресили покойника.",
    "category": "Чеклисты",
    "goal": 1
  },
  {
    "id": "meeting_note",
    "icon": "🎙️",
    "title": "Созвон мог быть этой заметкой",
    "description": "Написать заметку от 1500 символов. Сорок минут «коллеги, меня слышно?» уместились на одном экране.",
    "category": "Заметки",
    "goal": 1500
  },
  {
    "id": "novel",
    "icon": "📚",
    "title": "Толстой бы заебался",
    "description": "Написать в одной заметке 5000 символов. Война, мир и ещё два открытых вопроса к заказчику.",
    "category": "Заметки",
    "goal": 5000
  },
  {
    "id": "headings",
    "icon": "🗂️",
    "title": "Пиздецу присвоен заголовок",
    "description": "Добавить в одну заметку 3 Markdown-заголовка. Хаос остался, зато теперь по нему можно ориентироваться.",
    "category": "Заметки",
    "goal": 3
  },
  {
    "id": "markdown",
    "icon": "🖍️",
    "title": "Жирным, чтоб дошло, блядь",
    "description": "Выделить текст и сделать его жирным через всплывающую панель. На следующем созвоне всё равно спросят.",
    "category": "Заметки",
    "goal": 1
  },
  {
    "id": "no_deadline",
    "icon": "♾️",
    "title": "Срока нет. Совести тоже.",
    "description": "Создать 3 задачи без крайнего срока. Бессмертие оказалось бесплатной настройкой.",
    "category": "Дедлайны",
    "goal": 3
  },
  {
    "id": "deadline_added",
    "icon": "📌",
    "title": "У жопы появилась дата",
    "description": "Назначить крайний срок задаче, у которой его не было. Абстрактная тревога стала календарным событием.",
    "category": "Дедлайны",
    "goal": 1
  },
  {
    "id": "train",
    "icon": "🚒",
    "title": "Сдала, пока не закопали",
    "description": "Выполнить задачу в день её крайнего срока. Похоронный плейлист пока можно выключить.",
    "category": "Дедлайны",
    "goal": 1
  },
  {
    "id": "overdue_done",
    "icon": "🧀",
    "title": "Просрочено, зато охуенно",
    "description": "Выполнить просроченную задачу. Выдержанная аналитика. Нотки паники, послевкусие согласования.",
    "category": "Дедлайны",
    "goal": 1
  },
  {
    "id": "aged",
    "icon": "🛸",
    "title": "До второго пришествия бизнеса",
    "description": "Перевести задачу без срока в «Отложено». Когда бизнес вернётся с ответом, археологи её найдут.",
    "category": "Канбан",
    "goal": 1
  },
  {
    "id": "board_moves",
    "icon": "♟️",
    "title": "Карточки двигаются. Работа тоже?",
    "description": "Перетащить 5 карточек между колонками канбана. По отчёту движение есть. Не уточняйте какое.",
    "category": "Канбан",
    "goal": 5
  },
  {
    "id": "back_from_deferred",
    "icon": "⚰️",
    "title": "Раскопки имени «срочно надо»",
    "description": "Вернуть отложенную задачу в работу. Мамонт оказался живой и хочет правки до обеда.",
    "category": "Канбан",
    "goal": 1
  },
  {
    "id": "wip_three",
    "icon": "🤹",
    "title": "В работе всё. В ахуе я.",
    "description": "Держать 3 задачи одновременно в колонке «Выполняется». Многозадачность — это когда зависают сразу все вкладки в голове.",
    "category": "Канбан",
    "goal": 3
  }
];
achievements.push({id:'cat_pets',icon:'🐾',title:'Мур, сука',description:'Потыкать кота 5 раз. Самый стабильный стейкхолдер: хочет жрать, не меняет требования.',category:'Кошачья терапия',goal:5},{id:'night_cat',icon:'🌙',title:'Тёмная сторона лапки',description:'Включить ночную тему. Пиздец тот же, зато глаза не вытекают.',category:'Кошачья терапия',goal:1});
let achievementCategory='Все';
function recordEvent(type){const m=data.metrics;if(type==='descriptionEdit'){m.descriptionEdits=m.descriptionEdits||{};m.descriptionEdits[selectedId]=(m.descriptionEdits[selectedId]||0)+1}else m[type]=(m[type]||0)+1;save();}
function achievementProgress(id){
 const tasks=data.tasks,notes=tasks.flatMap(t=>t.notes),max=(list,fn)=>Math.max(0,...list.map(fn)),m=data.metrics;
 const values={cat_pets:m.catPets||0,night_cat:m.nightTheme||0,first:tasks.length,done:tasks.filter(t=>t.status==='done').length,fire:tasks.filter(t=>t.status==='done'&&t.completedAt===today).length,free:tasks.length>=3&&tasks.every(t=>t.status==='done')?1:0,
 requirements:max(tasks,t=>t.description.length),final_final:Math.max(0,...Object.values(m.descriptionEdits||{})),criteria:max(tasks,t=>/#{1,6}\s+Критерии при[её]мки/i.test(t.description)?(t.description.match(/^[-*] /gm)||[]).length:0),evidence:max(tasks,t=>([t.description,...t.notes.map(n=>n.text)].join('\n').match(/\[[^\]]+\]\(https?:\/\//g)||[]).length),decomposition:max(tasks,t=>t.checklist.length),clean:max(tasks,t=>percent(t)===100?t.checklist.length:0),checklist_spree:m.checked||0,checklist_return:m.rechecked||0,
 meeting_note:max(notes,n=>n.text.length),novel:max(notes,n=>n.text.length),headings:max(notes,n=>(n.text.match(/^#{1,6} /gm)||[]).length),markdown:m.bold||0,no_deadline:tasks.filter(t=>!t.due).length,deadline_added:m.deadline||0,train:m.onTime||0,overdue_done:m.lateDone||0,aged:m.deferred||0,board_moves:m.boardMove||0,back_from_deferred:m.revived||0,wip_three:activeTasks().length};return values[id]||0;
}
function evaluateAchievements(silent=false){achievements.forEach(a=>{if(achievementProgress(a.id)>=a.goal&&!data.unlocked.includes(a.id)){if(silent)data.unlocked.push(a.id);else unlock(a.id)}});save();const badge=$('.nav-achievement');if(badge)badge.textContent=`${data.unlocked.length}/${achievements.length}`;}
function renderAchievements(){
 const n=data.unlocked.length,categories=['Все',...new Set(achievements.map(a=>a.category))];
 $('#main').innerHTML=pageTop('Орден аналитического пиздеца','Выдан за выживание в среде, где «ничего сложного» — это угроза.',false)+`<div class="achievement-banner with-plants"><div class="medal">${catSvg('smug','achievement-cat')}</div><div><h2>Не выгорела. Прожарилась.</h2><p>${n} из ${achievements.length} наград за то, что этот цирк до сих пор работает.</p></div><div class="achievement-overall"><span>${n} / ${achievements.length} в коллекции</span><div class="progress-track"><div class="progress-fill" style="width:${n/achievements.length*100}%"></div></div></div>${plantGardenHtml("achievement-greenery")}</div><div class="achievement-category-tabs">${categories.map(c=>`<button class="${achievementCategory===c?'active':''}" data-achievement-category="${esc(c)}">${c}</button>`).join('')}</div><div class="achievement-grid">${achievements.filter(a=>achievementCategory==='Все'||a.category===achievementCategory).map(a=>{const earned=data.unlocked.includes(a.id),progress=Math.min(achievementProgress(a.id),a.goal);return `<article class="achievement-card ${earned?'':'locked'}"><span class="achievement-state">${earned?icon('check'):'◌'}${earned?'В кармане':'Ещё не вляпалась'}</span><div class="achievement-icon">${a.icon}</div><span class="achievement-category">${a.category}</span><h3>${a.title}</h3><p>${a.description}</p>${earned?`<span class="earned-date">Заслужила. Каким, блядь, трудом.</span>`:`<div class="progress-title"><span>До награды</span><span>${progress} / ${a.goal}</span></div><div class="progress-track"><div class="progress-fill" style="width:${progress/a.goal*100}%"></div></div>`}</article>`}).join('')}</div>`;
 $$('[data-achievement-category]').forEach(b=>b.onclick=()=>{achievementCategory=b.dataset.achievementCategory;renderAchievements()});
}

function renderMain(){const m=$('#main');m.classList.toggle('view-wide',view!=='list');if(view==='list')renderList();else if(view==='board')renderBoard();else if(view==='calendar')renderCalendar();else renderAchievements()}
function render(){renderNav();renderMain();renderDetail()}

function showModal(content){hideSelectionToolbar();$('.app-shell').inert=true;$('#task-overlay').inert=true;$('#modal-root').innerHTML=`<div class="modal-backdrop"><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">${content}</section></div>`;$('.modal-backdrop').onclick=e=>{if(e.target===$('.modal-backdrop'))closeModal()};$$('[data-close-modal]').forEach(b=>b.onclick=closeModal);setTimeout(()=>($('.modal input')||$('.modal textarea')||$('.modal button'))?.focus(),20)}
function closeModal(){$('#modal-root').innerHTML='';syncTaskInert()}
function modalHead(title){return `<div class="modal-header"><h2 id="modal-title">${title}</h2><button class="icon-btn" data-close-modal aria-label="Закрыть">${icon('close')}</button></div>`}
function inputModal(title,label,placeholder,callback,button='Сохранить',type='text'){
 showModal(modalHead(title)+`<form id="simple-form"><div class="form-field"><label for="simple-input">${label}</label><input id="simple-input" type="${type}" placeholder="${esc(placeholder)}" required autocomplete="off"></div><div class="modal-footer"><span>Зафиксируем, пока не переобулись.</span><button class="primary-btn" type="submit">${button} ↗</button></div></form>`);
 $('#simple-form').onsubmit=e=>{e.preventDefault();const value=$('#simple-input').value.trim();if(value){closeModal();callback(value)}};
}
function newTaskModal(project,status='created',due=''){
 const p=project||projectFilter||data.projects[0].id;
 showModal(modalHead('Что у нас в планах?')+`<p>Запиши, пока это не превратилось в ещё один созвон.</p><form id="new-task-form"><div class="form-field"><label for="new-title">Название задачи</label><input id="new-title" required maxlength="160" placeholder="Например, выбить из бизнеса нормальное ТЗ" autocomplete="off"></div><div class="form-pair"><div class="form-field"><label for="new-project">Проект</label><select id="new-project">${data.projects.map(pr=>`<option value="${pr.id}" ${pr.id===p?'selected':''}>${esc(pr.name)}</option>`).join('')}</select></div><div class="form-field"><label for="new-due">Крайний срок</label><input type="date" id="new-due" value="${due}"></div></div><div class="form-field"><label for="new-description">Описание · Markdown поддерживается</label><textarea id="new-description" placeholder="Немного контекста. Можно **жирным**."></textarea></div><div class="modal-footer"><span>Без срока? Так и запишем: срока нет.</span><button class="primary-btn" type="submit">${icon('plus')}Создать задачу</button></div></form>`);
 $('#new-task-form').onsubmit=e=>{e.preventDefault();const title=$('#new-title').value.trim();if(!title)return;const id=Math.max(0,...data.tasks.map(t=>t.id))+1;const task={id,title,project:$('#new-project').value,status,due:status==='deferred'?'':$('#new-due').value,priority:'normal',description:$('#new-description').value.trim(),checklist:[],notes:[],created:today};data.tasks.push(task);if(status==='done'){task.status='created';changeStatus(task,'done')}detailTab='overview';selectedNoteId=null;noteSourceMode=false;if(view==='achievements')view='list';editorState=null;selectedId=id;tab='all';if(projectFilter&&projectFilter!==task.project)projectFilter='';search='';$('#search').value='';onlyUrgent=false;save();closeModal();render();toast('Зафиксировано. Теперь официально твоя проблема.');unlock('first');evaluateAchievements();if(status==='deferred')unlock('aged')};
}
function taskMoreModal(t){showModal(modalHead('Задача PT–'+String(t.id).padStart(3,'0'))+`<p>${esc(t.title)}</p><button class="modal-menu-button" id="duplicate-task">Создать копию</button><button class="modal-menu-button" id="defer-task">Отложить на неопределённый срок</button><button class="modal-menu-button" id="delete-task" style="color:#ba7d8c">Удалить задачу</button>`);$('#duplicate-task').onclick=()=>{const copy=JSON.parse(JSON.stringify(t));copy.id=Math.max(...data.tasks.map(x=>x.id))+1;copy.title+=' — копия';copy.status='created';delete copy.completedAt;copy.created=today;editorState=null;data.tasks.push(copy);selectedId=copy.id;save();closeModal();render();toast('Копия задачи создана')};$('#defer-task').onclick=()=>{changeStatus(t,'deferred');save();closeModal();render();toast('Отложено. Пускай бизнес сначала определится.')};$('#delete-task').onclick=()=>{data.tasks=data.tasks.filter(x=>x.id!==t.id);selectedId=null;save();closeModal();render();toast('Задача удалена')}}
function settingsModal(){showModal(modalHead('Настройки этого цирка')+`<p>Пиздец не отключается. А тему поменять можно.</p><div class="setting-row"><span>Оформление<small>Дневная или ночная кошка</small></span><button class="theme-setting-button" id="theme-setting">${data.settings.theme==='dark'?'☾ Ночная кошка':'☀ Дневная кошка'}</button></div><div class="setting-row"><span>Лексика<small>Для созвонов, коллег и демонстраций</small></span><button class="theme-setting-button" id="language-setting">${data.settings.cleanLanguage?'Без мата':'Мат включён'}</button></div><div class="setting-row"><span>Сохранение<small>Данные остаются в этом браузере</small></span><span class="badge green">Автоматически</span></div><div class="shortcut"><span>Найти задачу</span><kbd>⌘ / Ctrl + K</kbd></div><div class="shortcut"><span>Новая задача</span><kbd>N</kbd></div><div class="shortcut"><span>Закрыть окно</span><kbd>Esc</kbd></div><div class="shortcut"><span>Жирный / курсив</span><kbd>⌘ / Ctrl + B / I</kbd></div><div class="modal-footer"><span>потом. · Лапки есть. ТЗ нет.</span><button class="primary-btn" data-close-modal>Мяу. Понятно.</button></div>`);$('#theme-setting').onclick=toggleTheme;$('#language-setting').onclick=toggleLanguageMode;}
$$('[data-view]').forEach(b=>b.onclick=()=>{view=b.dataset.view;onlyUrgent=false;selectedId=null;editorState=null;projectFilter='';$('#active-popover').classList.add('hidden');render()});
$('.brand').onclick=e=>{e.preventDefault();flushDocument();selectedId=null;detailTab='overview';view='board';projectFilter='';tab='all';search='';$('#search').value='';onlyUrgent=false;render()};
$('#search').oninput=e=>{search=e.target.value;if(view==='achievements')view='list';renderNav();renderMain()};
$('#active-toggle').onclick=e=>{e.stopPropagation();renderActivePopover();$('#active-popover').classList.toggle('hidden')};
document.addEventListener('click',e=>{if(!e.target.closest('.active-wrap'))$('#active-popover').classList.add('hidden')});
$('#add-project').onclick=()=>inputModal('Новое место для идей','Название проекта','Например, Большое приключение',name=>{data.projects.push({id:'project-'+Date.now(),name,color:['#b8afcf','#b7c5a2','#dfb29a'][data.projects.length%3]});save();renderNav();toast('У бардака появился отдельный кабинет.')} ,'Создать проект');
$('#settings').onclick=settingsModal;
$('#workspace-btn').onclick=()=>showModal(modalHead('Моё пространство')+`<p>Личный штаб по разбору чужих гениальных идей.</p><div class="setting-row"><span>Личное пространство<small>${data.projects.length} проекта · ${data.tasks.length} задач</small></span><span class="badge pink">Это ты</span></div><div class="modal-footer"><span>Все идеи в одном месте.</span><button class="primary-btn" data-close-modal>Продолжить ↗</button></div>`);
$('#profile').onclick=()=>showModal(modalHead('Привет 👋')+`<p>Ты, бэклог и нездоровое количество контекста.</p><div class="setting-row"><span>Закрыто задач</span><b>${data.tasks.filter(t=>t.status==='done').length}</b></div><div class="setting-row"><span>Открыто достижений</span><b>${data.unlocked.length} / ${achievements.length}</b></div><div class="modal-footer"><span>Лапки есть. Телепатии нет.</span><button class="primary-btn" data-close-modal>Вернуться к планам ↗</button></div>`);
document.addEventListener('keydown',e=>{
 const modal=$('.modal')||(!$('#task-overlay').classList.contains('hidden')?$('#detail'):null);
 if(e.key==='Tab'&&modal){const controls=$$('button,input,select,textarea,[contenteditable="true"],a[href]',modal).filter(x=>!x.disabled&&x.getClientRects().length),first=controls[0],last=controls[controls.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus()}}
 if(e.key==='Escape'){if($('#modal-root').children.length){closeModal();return}if(!$('#selection-toolbar').classList.contains('hidden')){hideSelectionToolbar();return}if(selectedId){closeTask();return}$('#active-popover').classList.add('hidden');}
 if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'&&!e.target.closest('[data-editor-field]')){e.preventDefault();if(!selectedId)$('#search').focus()}
 if(e.key.toLowerCase()==='n'&&!e.metaKey&&!e.ctrlKey&&!['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName)&&!e.target.isContentEditable&&!modal)newTaskModal();
});
$('#task-overlay').onclick=e=>{if(e.target===$('#task-overlay'))closeTask()};
$$('[data-doc-format]').forEach(b=>b.onclick=()=>applyDocumentFormat(b.dataset.docFormat));
applyTheme();applyLanguageMode();evaluateAchievements(true);

save();render();
