const catRemarks=[
 'Лапки есть. ТЗ нет.',
 'Мяу. Бизнес опять насрал в требования.',
 'Созвон на пять минут? Пиздёж.',
 'Погладь кота. Таску трогать страшнее.',
 'Я не токсичная. Я читала этот бэклог.',
 'Мур. Теперь закрой эту херню.',
 'У меня девять жизней. У тебя один дедлайн.',
 'Кусь за «там просто кнопочку».',
 'Требования уточнили. Я охуела уточнённо.',
 'Котик хочет спать. Бизнес хочет всё.'
];
let catRemarkIndex=0;
function catVector(mood='smug',className='cat-card-art'){
 const sleepy=mood==='sleep',chaos=mood==='chaos';
 return `<svg class="cat-mascot ${className}" viewBox="0 0 160 140" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="${sleepy?'Сонная кошечка':chaos?'Кошка в ахуе':'Самодовольная кошечка'}"><ellipse cx="82" cy="129" rx="49" ry="5" class="cat-shadow"/><path d="M111 114c33 9 45-18 29-28-9-6-13 5-6 8" class="cat-tail" stroke-width="10" stroke-linecap="round"/><path d="M46 111c-3-30 9-50 33-50 29 0 40 22 36 53-7 17-62 19-69-3Z" class="cat-body" stroke-width="2"/><path d="M66 113c-5-18-2-27 1-31m27 31c5-18 2-27-1-31" class="cat-line" stroke-width="1.8" stroke-linecap="round"/><path d="M42 52 38 16c-1-5 3-8 7-5l25 18c8-2 15-2 23 0l24-18c4-3 8 0 7 5l-4 38c7 23-9 41-40 41-34 0-47-19-38-43Z" class="cat-body" stroke-width="2"/><path d="m46 23 3 24 15-12-18-12Zm70 0-3 24-14-12 17-12Z" class="cat-inner-ear"/><ellipse cx="56" cy="65" rx="9" ry="5" class="cat-blush"/><ellipse cx="105" cy="65" rx="9" ry="5" class="cat-blush"/>${sleepy?'<path d="m57 53 6 4 6-4m24 0 6 4 6-4" class="cat-eye" stroke-width="2.5" stroke-linecap="round"/>':chaos?'<ellipse cx="64" cy="54" rx="4" ry="6" class="cat-eye-fill"/><ellipse cx="99" cy="54" rx="4" ry="6" class="cat-eye-fill"/>':'<path d="M56 53h15m21 0h15m-43 0v5m35-5v5" class="cat-eye" stroke-width="2.5" stroke-linecap="round"/>'}<path d="m77 64 4 3 4-3" class="cat-eye" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>${chaos?'<ellipse cx="81" cy="76" rx="5" ry="7" class="cat-eye" stroke-width="2"/>':'<path d="M81 67v5m0 0c-6 6-10 2-10-1m10 1c6 6 10 2 10-1" class="cat-eye" stroke-width="1.8" stroke-linecap="round"/>'}<path d="m49 65-19-3m19 10-17 3m80-10 18-3m-18 10 17 3" class="cat-line" stroke-width="1.5" stroke-linecap="round"/><path d="M52 120c3-8 13-8 16 0m27 0c3-8 13-8 16 0" class="cat-line" stroke-width="1.6" stroke-linecap="round"/><path d="m19 34 2-6 2 6 6 2-6 2-2 6-2-6-6-2 6-2Z" class="cat-spark"/><path d="m140 45 2-4 1 4 4 1-4 2-1 4-2-4-4-2 4-1Z" class="cat-spark"/>${sleepy?'<text x="126" y="24" class="cat-z" font-size="12">z z</text>':'<path d="M75 107c-10-11-17 3 6 14 23-11 16-25 6-14l-6 4-6-4Z" class="cat-heart"/>'}</svg>`;
}
function catSvg(mood='smug',className='cat-card-art'){
 const cat=mood==='sleep'?{file:'cat-maine-coon',name:'Серебристый мейн-кун'}:mood==='chaos'?{file:'cat-angora',name:'Белая турецкая ангора'}:{file:'cat-british',name:'Серый британский кот'};
 return `<img class="cat-mascot photo-cat ${className}" src="assets/${cat.file}.png" alt="${cat.name}" draggable="false" decoding="async">`;
}
function plantGardenHtml(className='desktop-garden'){
 return `<span class="${className}" aria-hidden="true"><img class="garden-syngonium" src="assets/plant-syngonium.png" alt="" decoding="async"><img class="garden-epipremnum" src="assets/plant-epipremnum.png" alt="" decoding="async"></span>`;
}
function applyTheme(){
 const theme=data.settings.theme==='dark'?'dark':'light';document.documentElement.dataset.theme=theme;document.documentElement.style.colorScheme=theme;
 const button=$('#theme-toggle');button.innerHTML=`<span>${theme==='dark'?'☀':'☾'}</span>`;button.setAttribute('aria-label',theme==='dark'?'Включить светлую тему':'Включить тёмную тему');button.title=theme==='dark'?'Дневная кошка':'Ночная кошка';
 $('#sidebar-cat-art').innerHTML=catSvg(theme==='dark'?'sleep':'smug');const garden=$('#sidebar-garden');if(garden)garden.innerHTML=plantGardenHtml();
 const setting=$('#theme-setting');if(setting)setting.textContent=theme==='dark'?'☾ Ночная кошка':'☀ Дневная кошка';
 button.onclick=toggleTheme;
 $('#cat-quip').onclick=()=>{catRemarkIndex=(catRemarkIndex+1)%catRemarks.length;$('#cat-quote').textContent=catRemarks[catRemarkIndex];$('#sidebar-cat-art').innerHTML=catSvg(['smug','chaos','sleep'][catRemarkIndex%3]);recordEvent('catPets');evaluateAchievements();const cat=$('#sidebar-cat-art');cat.classList.remove('cat-boop');void cat.offsetWidth;cat.classList.add('cat-boop')};
}
function toggleTheme(){flushDocument();data.settings.theme=data.settings.theme==='dark'?'light':'dark';if(data.settings.theme==='dark')recordEvent('nightTheme');save();applyTheme();evaluateAchievements();}
