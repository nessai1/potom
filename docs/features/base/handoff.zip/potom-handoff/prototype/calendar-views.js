let calendarMode = 'month';

function calendarLabelCount(count, forms = ['задача', 'задачи', 'задач']) {
  const n = Math.abs(count), last = n % 10;
  return `${count} ${forms[n % 100 >= 11 && n % 100 <= 14 ? 2 : last === 1 ? 0 : last >= 2 && last <= 4 ? 1 : 2]}`;
}
function calendarShiftDate(key, amount) {
  const date = parseDate(key);
  date.setDate(date.getDate() + amount);
  return date;
}
function calendarWeekDates() {
  const selected = parseDate(selectedDay), monday = new Date(selected);
  monday.setDate(selected.getDate() - (selected.getDay() + 6) % 7);
  return Array.from({ length: 7 }, (_, index) => {
    const date = new Date(monday);
    date.setDate(monday.getDate() + index);
    return date;
  });
}
function calendarLongDate(date) {
  return date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' }).replace(' г.', '');
}
function calendarTasksFor(tasks, key) {
  return tasks.filter(task => task.due === key).sort((a, b) =>
    Number(a.status === 'done') - Number(b.status === 'done') ||
    Number(b.priority === 'high') - Number(a.priority === 'high') || Number(a.id) - Number(b.id));
}
function calendarTaskCard(task, compact = false) {
  const project = getProject(task.project);
  return `<button class="cal-task-card ${compact ? 'compact' : ''} ${task.status === 'done' ? 'is-done' : ''}" data-cal-task="${task.id}" aria-label="Открыть задачу: ${esc(task.title)}">
    <span class="cal-task-card-top"><span class="cal-task-project"><i class="project-dot" style="background:${project.color}"></i>${esc(project.name)}</span><span class="cal-task-id">PT–${String(task.id).padStart(3, '0')}</span></span>
    <strong class="cal-task-card-title">${esc(task.title)}</strong>
    <span class="cal-task-card-status">${badge(task)}${task.priority === 'high' ? `<span class="cal-high-priority">${icon('flag')}Высокий</span>` : ''}</span>
    <span class="cal-task-card-bottom"><span>${task.checklist.length ? `${doneCount(task)} из ${task.checklist.length} пунктов` : 'Без чеклиста'}</span>${task.checklist.length ? `<b>${percent(task)}%</b>` : ''}</span>
    ${task.checklist.length ? `<span class="cal-card-progress"><i style="width:${percent(task)}%"></i></span>` : ''}
  </button>`;
}
function calendarMonthHtml(tasks) {
  const year = calendarMonth.getFullYear(), month = calendarMonth.getMonth();
  const start = new Date(year, month, 1), shift = (start.getDay() + 6) % 7;
  const length = new Date(year, month + 1, 0).getDate(), cells = Math.ceil((length + shift) / 7) * 7;
  const selectedTasks = calendarTasksFor(tasks, selectedDay);
  return `<div class="cal-month-grid" aria-label="Календарь на месяц">
    ${['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС'].map((day, index) => `<div class="cal-weekday ${index > 4 ? 'weekend' : ''}">${day}</div>`).join('')}
    ${Array.from({ length: cells }, (_, index) => {
      const date = new Date(year, month, 1 - shift + index), key = dateKey(date), dayTasks = calendarTasksFor(tasks, key);
      return `<section class="cal-month-day ${date.getMonth() !== month ? 'other-month' : ''} ${index % 7 > 4 ? 'weekend' : ''} ${key === today ? 'is-today' : ''} ${key === selectedDay ? 'is-selected' : ''}" data-cal-cell="${key}">
        <button class="cal-month-date" data-cal-day="${key}" aria-pressed="${key === selectedDay}" aria-label="${esc(calendarLongDate(date))}, ${calendarLabelCount(dayTasks.length)}"><span>${date.getDate()}</span>${dayTasks.length ? `<small>${dayTasks.length}</small>` : ''}</button>
        <div class="cal-month-events">${dayTasks.slice(0, 3).map(task => `<button class="cal-month-event ${task.status === 'done' ? 'is-done' : task.project === 'work' ? 'is-yellow' : ''}" data-cal-task="${task.id}" title="${esc(task.title)}">${task.status === 'done' ? '✓ ' : ''}${esc(task.title)}</button>`).join('')}</div>
        ${dayTasks.length > 3 ? `<button class="cal-month-more" data-cal-open-day="${key}">Ещё ${dayTasks.length - 3} ${icon('chevron')}</button>` : ''}
      </section>`;
    }).join('')}
  </div>
  <section class="cal-selected-panel"><div class="cal-selected-heading"><div><span class="cal-eyebrow">ВЫБРАННЫЙ ДЕНЬ</span><h2>${calendarLongDate(parseDate(selectedDay))}</h2></div><button class="secondary-btn" data-cal-open-day="${selectedDay}">Открыть день ${icon('chevron')}</button></div>
    ${selectedTasks.length ? `<div class="cal-selected-list">${selectedTasks.map(task => `<button class="cal-selected-task" data-cal-task="${task.id}"><span>${esc(task.title)}</span>${badge(task)}${icon('chevron')}</button>`).join('')}</div>` : '<p class="cal-selected-empty">На эту дату сроков нет. В календаре тихо.</p>'}
  </section>`;
}
function calendarWeekHtml(tasks, dates) {
  return `<div class="cal-week-scroll" tabindex="0" aria-label="Неделя: семь дней, задачи без привязки ко времени"><div class="cal-week-grid">
    ${dates.map((date, index) => {
      const key = dateKey(date), dayTasks = calendarTasksFor(tasks, key);
      return `<section class="cal-week-column ${index > 4 ? 'weekend' : ''} ${key === today ? 'is-today' : ''} ${key === selectedDay ? 'is-selected' : ''}">
        <button class="cal-week-date" data-cal-day="${key}" aria-pressed="${key === selectedDay}" aria-label="Выбрать ${esc(calendarLongDate(date))}"><span>${date.toLocaleDateString('ru-RU', { weekday: 'short' })}</span><strong>${date.getDate()}</strong><small>${key === today ? 'Сегодня' : date.toLocaleDateString('ru-RU', { month: 'short' }).replace('.', '')}</small></button>
        <div class="cal-all-day"><span>Весь день</span><b>${dayTasks.length}</b></div>
        <div class="cal-week-tasks">${dayTasks.length ? dayTasks.map(task => calendarTaskCard(task, true)).join('') : '<span class="cal-week-empty">Сроков нет.<br>Пока.</span>'}</div>
        <button class="cal-week-add" data-cal-add-date="${key}" aria-label="Добавить задачу на ${esc(calendarLongDate(date))}">${icon('plus')}Задача</button>
      </section>`;
    }).join('')}
  </div></div>`;
}
function calendarUpcomingGroups(tasks, startDay = selectedDay) {
  return Array.from({ length: 7 }, (_, offset) => {
    const date = calendarShiftDate(startDay, offset), key = dateKey(date);
    return { date, key, tasks: calendarTasksFor(tasks, key) };
  });
}
function calendarAgendaRangeLabel(startDay = selectedDay) {
  const end = calendarShiftDate(startDay, 6), start = parseDate(startDay);
  const years = start.getFullYear() === end.getFullYear() ? end.getFullYear() : start.getFullYear() + ' / ' + end.getFullYear();
  return `${shortDate(startDay)} — ${shortDate(dateKey(end))} · ${years}`;
}
function calendarDayHtml(tasks) {
  const date = parseDate(selectedDay), groups = calendarUpcomingGroups(tasks), upcomingCount = groups.reduce((sum, group) => sum + group.tasks.length, 0);
  const populatedGroups = groups.filter(group => group.tasks.length);
  return `<section class="cal-day-view"><div class="cal-day-summary"><div class="cal-day-number ${selectedDay === today ? 'is-today' : ''}">${date.getDate()}</div><div><span class="cal-eyebrow">${selectedDay === today ? 'БЛИЖАЙШИЕ 7 ДНЕЙ' : '7 ДНЕЙ С ВЫБРАННОЙ ДАТЫ'}</span><h2>${calendarAgendaRangeLabel()}</h2><p>${calendarLabelCount(upcomingCount)} по крайнему сроку · все статусы · по датам</p></div></div>
    ${upcomingCount ? `<div class="cal-upcoming-agenda">${populatedGroups.map(group => `<section class="cal-agenda-day" data-agenda-date="${group.key}"><header class="cal-agenda-day-heading"><span class="cal-eyebrow">${group.key === today ? 'СЕГОДНЯ' : group.date.toLocaleDateString('ru-RU', { weekday: 'long' }).toUpperCase()}</span><h3>${group.date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })}</h3><small>${calendarLabelCount(group.tasks.length)}</small><button class="cal-week-add" data-cal-add-date="${group.key}" aria-label="Добавить задачу на ${esc(calendarLongDate(group.date))}">${icon('plus')}Задача</button></header><div class="cal-day-task-grid">${group.tasks.map(task => calendarTaskCard(task)).join('')}</div></section>`).join('')}</div>` : `<div class="cal-day-empty">${catSvg('sleep', 'empty-cat')}<h3>В ближайшие 7 дней дедлайнов нет</h3><p>Календарь пока делает вид, что всё спокойно.</p><button class="secondary-btn" data-cal-add-date="${selectedDay}">${icon('plus')}Добавить задачу</button></div>`}
  </section>`;
}
function renderCalendar() {
  const tasks = filteredTasks(), dates = calendarWeekDates();
  let title;
  if (calendarMode === 'month') title = calendarMonth.toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' }).replace(' г.', '');
  else if (calendarMode === 'week') title = `${shortDate(dateKey(dates[0]))} — ${shortDate(dateKey(dates[6]))} · ${dates[0].getFullYear() === dates[6].getFullYear() ? dates[6].getFullYear() : dates[0].getFullYear() + ' / ' + dates[6].getFullYear()}`;
  else title = calendarAgendaRangeLabel();
  title = title.charAt(0).toUpperCase() + title.slice(1);
  const modeNames = { month: 'месяц', week: 'неделю', day: 'день' };
  const undated = tasks.filter(task => !task.due && task.status !== 'done').length;
  $('#main').innerHTML = pageTop('Календарь', 'У каждой паники есть дата.') + `<div class="cal-view-controls"><div class="cal-period-navigation"><button class="cal-nav-arrow" id="cal-previous" aria-label="Назад на ${modeNames[calendarMode]}">${icon('chevron')}</button><button class="cal-nav-arrow" id="cal-next" aria-label="Вперёд на ${modeNames[calendarMode]}">${icon('chevron')}</button><h2>${esc(title)}</h2><button class="cal-today-button" id="cal-today">Сегодня</button></div><div class="cal-mode-switch" role="group" aria-label="Вид календаря">${[['month', 'Месяц'], ['week', 'Неделя'], ['day', 'День']].map(([mode, label]) => `<button class="${calendarMode === mode ? 'active' : ''}" data-calendar-mode="${mode}" aria-pressed="${calendarMode === mode}">${label}</button>`).join('')}</div></div>
    <div class="cal-view-meta"><span>${icon('calendar')}По крайнему сроку задачи</span><label class="cal-date-jump">К дате<input type="date" id="cal-date-picker" value="${selectedDay}" aria-label="Выбрать дату календаря"></label></div>
    ${calendarMode === 'month' ? calendarMonthHtml(tasks) : calendarMode === 'week' ? calendarWeekHtml(tasks, dates) : calendarDayHtml(tasks)}
    <div class="cal-bottom-note">${icon('clock')}${undated ? `${calendarLabelCount(undated)} без срока — к календарю не привязаны.` : 'Задачи без срока сюда не попадают.'}</div>`;

  $('[data-new]', $('#main')).onclick = () => newTaskModal(null, 'created', selectedDay);
  $$('[data-calendar-mode]', $('#main')).forEach(button => button.onclick = () => {
    const nextMode = button.dataset.calendarMode;
    if (nextMode === 'day' && calendarMode !== 'day') { selectedDay = today; calendarMonth = parseDate(today); }
    calendarMode = nextMode;
    renderCalendar();
  });
  const shiftPeriod = amount => {
    if (calendarMode === 'month') {
      const nextMonth = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() + amount, 1);
      const day = Math.min(parseDate(selectedDay).getDate(), new Date(nextMonth.getFullYear(), nextMonth.getMonth() + 1, 0).getDate());
      calendarMonth = nextMonth;
      selectedDay = dateKey(new Date(nextMonth.getFullYear(), nextMonth.getMonth(), day));
    }
    else {
      selectedDay = dateKey(calendarShiftDate(selectedDay, amount * (calendarMode === 'week' ? 7 : 1)));
      const date = parseDate(selectedDay);
      calendarMonth = new Date(date.getFullYear(), date.getMonth(), 1);
    }
    renderCalendar();
  };
  $('#cal-previous').onclick = () => shiftPeriod(-1);
  $('#cal-next').onclick = () => shiftPeriod(1);
  $('#cal-today').onclick = () => { selectedDay = today; calendarMonth = parseDate(today); renderCalendar(); };
  $('#cal-date-picker').onchange = event => {
    if (!event.target.value || !event.target.validity.valid) return;
    selectedDay = event.target.value;
    const date = parseDate(selectedDay);
    calendarMonth = new Date(date.getFullYear(), date.getMonth(), 1);
    renderCalendar();
  };
  $$('[data-cal-day]', $('#main')).forEach(button => button.onclick = () => { selectedDay = button.dataset.calDay; renderCalendar(); });
  $$('[data-cal-cell]', $('#main')).forEach(cell => cell.onclick = event => {
    if (event.target.closest('button')) return;
    selectedDay = cell.dataset.calCell;
    renderCalendar();
  });
  $$('[data-cal-open-day]', $('#main')).forEach(button => button.onclick = () => { selectedDay = button.dataset.calOpenDay; calendarMode = 'day'; renderCalendar(); });
  $$('[data-cal-task]', $('#main')).forEach(button => button.onclick = event => { event.stopPropagation(); openTask(button.dataset.calTask); });
  $$('[data-cal-add-date]', $('#main')).forEach(button => button.onclick = () => { selectedDay = button.dataset.calAddDate; newTaskModal(null, 'created', selectedDay); });
}
