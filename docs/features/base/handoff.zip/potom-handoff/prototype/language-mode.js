// The presentation filter changes visible copy, never the saved task content.
const originalCopyNodes=new WeakMap(),originalCopyAttributes=new WeakMap();
let copyObserver=null,copyUpdateQueued=false;
function cleanInterfaceCopy(value){
 const exact={
  'Орден аналитического пиздеца':'Орден аналитической стойкости',
  'Календарь горящих жоп':'Календарь горящих дедлайнов',
  'Одной хернёй меньше':'Минус одна проблема',
  'Пять жоп за один присест':'Пять пожаров за один присест',
  'Бэклог, соси':'Бэклог, отдыхай',
  'Я вам не Ванга, блядь':'Я вам не Ванга',
  'ТЗ_final_ЕБАНЫЙ_ФИНАЛ':'ТЗ_final_точно_последний',
  'Каждую срань — под галочку':'Каждую мелочь — под галочку',
  'Толстой бы заебался':'Толстой бы устал',
  'Пиздецу присвоен заголовок':'Хаосу присвоен заголовок',
  'Жирным, чтоб дошло, блядь':'Жирным, чтобы заметили',
  'У жопы появилась дата':'У паники появилась дата',
  'Просрочено, зато охуенно':'Просрочено, зато отлично',
  'В работе всё. В ахуе я.':'В работе всё. В шоке я.',
  'Мур, сука':'Мур. Официально.',
  'Пиздец тот же, зато глаза не вытекают.':'Хаос тот же, зато глаза не устают.',
  'Созвон на пять минут? Пиздёж.':'Созвон на пять минут? Верится с трудом.',
  'Мяу. Бизнес опять насрал в требования.':'Мяу. Бизнес опять переписал требования.',
  'Мур. Теперь закрой эту херню.':'Мур. Теперь закрой эту задачу.',
  'Требования уточнили. Я охуела уточнённо.':'Требования уточнили. Удивилась повторно.',
  '«Там на пять минут».\nМяу, блядь, конечно.':'«Там на пять минут».\nМяу. Конечно.',
  'Мяу, блядь, конечно.':'Мяу. Конечно.',
  'Заслужила. Каким, блядь, трудом.':'Заслужила. Каким трудом — отдельная история.',
  'Одна херня закрыта. Несите следующую.':'Одна задача закрыта. Несите следующую.'
 };
 let text=String(value);
 for(const [source,clean] of Object.entries(exact))text=text.split(source).join(clean);
 const substitutions=[
  [/пиздёж/giu,'сказки'],[/пиздецу/giu,'хаосу'],[/пиздец/giu,'хаос'],
  [/заебался/giu,'устал'],[/[её]баный/giu,'последний'],[/охуела/giu,'удивилась'],[/охуенно/giu,'отлично'],[/в ахуе/giu,'в шоке'],
  [/херн[её]й/giu,'задачей'],[/херню/giu,'задачу'],[/херня/giu,'задача'],[/срань/giu,'мелочь'],[/насрал/giu,'добавил хаоса'],
  [/жопы/giu,'проблемы'],[/жоп/giu,'проблем'],[/(?<![А-Яа-яЁё])блядь(?![А-Яа-яЁё])/giu,''],[/(?<![А-Яа-яЁё])сука(?![А-Яа-яЁё])/giu,'']
 ];
 for(const [pattern,replacement] of substitutions)text=text.replace(pattern,replacement);
 return text.replace(/ {2,}/g,' ').replace(/,\s*,/g,',').replace(/,\s*([.!?])/g,'$1').replace(/\s+([.!?])/g,'$1');
}
function visibleCopyRecord(value,record,cleanMode){
 const original=record&&(value===record.clean||value===record.original)?record.original:value;
 const clean=cleanInterfaceCopy(original);
 return {original,clean,value:cleanMode?clean:original};
}
function paintLanguageMode(){
 copyUpdateQueued=false;if(!copyObserver)return;copyObserver.disconnect();
 const cleanMode=!!data.settings.cleanLanguage;
 const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let node;
 while((node=walker.nextNode())){
  if(!node.parentElement||node.parentElement.closest('script,style,textarea,[data-editor-field]'))continue;
  const result=visibleCopyRecord(node.data,originalCopyNodes.get(node),cleanMode);
  originalCopyNodes.set(node,result);if(node.data!==result.value)node.data=result.value;
 }
 $$('[aria-label],[title],[placeholder],[data-placeholder]').forEach(el=>{
  if(el.closest('script,style'))return;const records=originalCopyAttributes.get(el)||{};
  ['aria-label','title','placeholder','data-placeholder'].forEach(name=>{if(!el.hasAttribute(name))return;const result=visibleCopyRecord(el.getAttribute(name),records[name],cleanMode);records[name]=result;if(el.getAttribute(name)!==result.value)el.setAttribute(name,result.value)});
  originalCopyAttributes.set(el,records);
 });
 copyObserver.observe(document.body,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['aria-label','title','placeholder','data-placeholder']});
}
function applyLanguageMode(){
 const clean=!!data.settings.cleanLanguage;document.documentElement.dataset.cleanLanguage=clean;
 const button=$('#language-toggle');button.innerHTML=clean?'<span>✧</span> Без мата':'<span>✳</span> Мат: вкл';button.classList.toggle('clean',clean);button.setAttribute('aria-pressed',String(clean));button.setAttribute('aria-label',clean?'Включить мат':'Включить режим без мата');button.title=clean?'Можно показывать коллегам':'Неформальный режим';button.onclick=toggleLanguageMode;
 const setting=$('#language-setting');if(setting){setting.textContent=clean?'Без мата':'Мат включён';setting.onclick=toggleLanguageMode}
 if(!copyObserver)copyObserver=new MutationObserver(()=>{if(!copyUpdateQueued){copyUpdateQueued=true;queueMicrotask(paintLanguageMode)}});
 paintLanguageMode();
}
function toggleLanguageMode(){flushDocument();data.settings.cleanLanguage=!data.settings.cleanLanguage;save();applyLanguageMode();toast(data.settings.cleanLanguage?'Режим без мата. Можно показывать коллегам.':'Мат вернулся. Аналитика тоже.')}
