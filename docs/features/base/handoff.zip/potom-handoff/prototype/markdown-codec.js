/* Browser globals: marked, DOMPurify, TurndownService, turndownPluginGfm. */
(function (global) {
  'use strict';

  const allowedTags = [
    'p', 'br', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'strong', 'b', 'em', 'i',
    's', 'del', 'strike', 'blockquote', 'ul', 'ol', 'li', 'a', 'code', 'pre',
    'hr', 'table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td', 'img', 'input',
    'div', 'span', 'sup', 'sub', 'kbd'
  ];
  const allowedAttributes = [
    'href', 'title', 'src', 'alt', 'width', 'height', 'align', 'colspan',
    'rowspan', 'type', 'checked', 'disabled', 'start', 'value', 'class',
    'data-language', 'data-checked'
  ];

  function cleanFragment(html) {
    const fragment = global.DOMPurify.sanitize(String(html || ''), {
      ALLOWED_TAGS: allowedTags,
      ALLOWED_ATTR: allowedAttributes,
      ALLOW_DATA_ATTR: false,
      ALLOW_ARIA_ATTR: false,
      RETURN_DOM_FRAGMENT: true
    });

    // Markdown may contain raw HTML. Keep code language metadata, but prevent
    // arbitrary classes from borrowing the application's layout and controls.
    fragment.querySelectorAll('[class]').forEach(function (node) {
      const language = node.tagName === 'CODE'
        ? Array.from(node.classList).find(function (name) { return /^language-[\w.+#-]+$/.test(name); })
        : null;
      if (language) node.className = language;
      else node.removeAttribute('class');
    });
    fragment.querySelectorAll('a[href]').forEach(function (link) {
      link.setAttribute('target', '_blank');
      link.setAttribute('rel', 'noopener noreferrer');
    });
    fragment.querySelectorAll('input').forEach(function (input) {
      if (input.getAttribute('type') !== 'checkbox') input.remove();
      else {
        input.disabled = true;
        input.setAttribute('contenteditable', 'false');
      }
    });
    // Accept task-list DOM created by the previous prototype as well as GFM's
    // native disabled checkboxes, without changing the persisted data schema.
    fragment.querySelectorAll('li[data-checked]').forEach(function (item) {
      if (!Array.from(item.children).some(function (node) { return node.tagName === 'INPUT'; })) {
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.disabled = true;
        checkbox.checked = item.dataset.checked === 'true';
        checkbox.setAttribute('contenteditable', 'false');
        item.prepend(checkbox, document.createTextNode(' '));
      }
    });
    return fragment;
  }

  const service = new global.TurndownService({
    headingStyle: 'atx',
    hr: '---',
    bulletListMarker: '-',
    codeBlockStyle: 'fenced',
    fence: '```',
    emDelimiter: '*',
    strongDelimiter: '**',
    linkStyle: 'inlined'
  });
  service.use(global.turndownPluginGfm.gfm);

  // The upstream GFM plugin uses single tildes; CommonMark/GFM needs two.
  service.addRule('potomStrikethrough', {
    filter: ['del', 's', 'strike'],
    replacement: function (content) { return '~~' + content + '~~'; }
  });
  // GFM table cells must escape literal pipes even inside inline code.
  service.addRule('potomTableCell', {
    filter: ['th', 'td'],
    replacement: function (content, node) {
      const index = Array.prototype.indexOf.call(node.parentNode.children, node);
      const cell = content.trim().replace(/\|/g, '\\|').replace(/\n+/g, '<br>');
      return (index === 0 ? '| ' : ' ') + cell + ' |';
    }
  });
  service.addRule('potomTaskCheckbox', {
    filter: function (node) {
      return node.nodeName === 'INPUT' && node.type === 'checkbox' && !!node.closest('li');
    },
    replacement: function (content, node) { return (node.checked ? '[x]' : '[ ]') + ' '; }
  });
  service.addRule('potomTableBreak', {
    filter: function (node) { return node.nodeName === 'BR' && !!node.closest('td,th'); },
    replacement: function () { return '<br>'; }
  });

  global.markdownToHtml = function (source) {
    const html = global.marked.parse(String(source || ''), { gfm: true, breaks: false, async: false });
    const container = document.createElement('div');
    container.append(cleanFragment(html));
    return container.innerHTML;
  };

  global.htmlToMarkdown = function (root) {
    const html = typeof root === 'string' ? root : root && root.innerHTML || '';
    const container = document.createElement('div');
    container.append(cleanFragment(html));
    return service.turndown(container).trim();
  };
})(window);
