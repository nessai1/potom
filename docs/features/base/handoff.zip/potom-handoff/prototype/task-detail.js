// Task dialogs and document editing share the same Markdown representation.
let detailTab='overview',selectedNoteId=null,noteSourceMode=false,taskFullscreen=false;
let documentSelection=null,documentEditor=null,documentSourceSelection=null,documentSaveTimer;
let taskReturnFocus=null;

function taskNoteTitle(note){return note.title||note.text.match(/^#{1,6}\s+(.+)/m)?.[1]||note.text.replace(/[*_`#]/g,'').split('\n')[0].slice(0,42)||'Без названия'}
function taskWordCount(value){return value.trim()?value.trim().split(/\s+/).length:0}
function currentNote(t){return t.notes.find(n=>n.id===selectedNoteId)||t.notes[0]}
function syncTaskInert(){const hasModal=!!$('#modal-root').children.length,hasTask=!!getTask(selectedId);$('.app-shell').inert=hasModal||hasTask;$('#task-overlay').inert=hasModal}
function hideSelectionToolbar(){$('#selection-toolbar').classList.add('hidden')}
function flushDocument(){if(documentEditor&&documentEditor.isConnected)saveDocumentEditor(documentEditor);clearTimeout(documentSaveTimer)}
function closeTask(){flushDocument();hideSelectionToolbar();selectedId=null;documentSelection=null;documentEditor=null;$('#task-overlay').classList.add('hidden');syncTaskInert();renderMain();taskReturnFocus?.focus?.()}
function openTask(id){flushDocument();taskReturnFocus=document.activeElement;selectedId=+id;detailTab='overview';selectedNoteId=getTask(id)?.notes[0]?.id??null;noteSourceMode=false;taskFullscreen=false;$('#active-popover').classList.add('hidden');renderMain();renderDetail();$('#close-detail')?.focus()}
function richEditorHtml(value,field,source=false){
 return source?`<textarea class="document-source" id="document-source" data-editor-field="${field}" aria-label="Исходный Markdown" spellcheck="false">${esc(value)}</textarea>`:`<div class="rich-editor ${field==='description'?'description-rich-editor':''}" id="${field==='description'?'description-editor':'note-editor'}" contenteditable="true" role="textbox" aria-multiline="true" aria-label="${field==='description'?'Описание задачи':'Документ заметки'}" data-editor-field="${field}" data-placeholder="${field==='description'?'Что нужно сделать и какого чёрта это опять срочно?':'Пиши. Тут поместится и ТЗ, и протокол, и весь этот цирк.'}" spellcheck="false">${markdownToHtml(value)||'<p><br></p>'}</div>`;
}
function renderDetail(){
 flushDocument();
 const t=getTask(selectedId),overlay=$('#task-overlay'),el=$('#detail');hideSelectionToolbar();documentSelection=null;documentSourceSelection=null;documentEditor=null;
 overlay.classList.toggle('hidden',!t);if(!t){syncTaskInert();return}
 syncTaskInert();el.classList.toggle('fullscreen',taskFullscreen);
 const project=getProject(t.project),d=dayDiff(t.due);
 const deadlineTitle=!t.due?'Срока нет':t.status==='done'?'Выполнено':d<0?`Просрочено на ${Math.abs(d)} ${ruDay(d)}`:d===0?'Дедлайн сегодня':`Осталось ${d} ${ruDay(d)}`;
 const deadlineText=!t.due?'Дата не назначена. Хрустальный шар тоже.':t.status==='done'?'Эту задачу уже можно не носить в голове.':d<0?'Задача уже не горит. Она обуглилась.':d===0?'«Успею» — тоже стратегия. Хреновая, но стратегия.':'Пока это срок, а не причина дёргаться.';
 el.innerHTML=`<div class="task-dialog-header"><div class="task-path"><span class="project-dot" style="background:${project.color}"></span>${esc(project.name)}<span>/</span><span>PT–${String(t.id).padStart(3,'0')}</span></div><div class="task-header-actions"><button class="icon-btn" id="task-more" aria-label="Действия с задачей">${icon('more')}</button><button class="icon-btn" id="expand-detail" aria-label="Развернуть окно">${icon('expand')}</button><button class="icon-btn" id="close-detail" aria-label="Закрыть задачу">${icon('close')}</button></div></div><div class="task-dialog-tabs"><button class="task-tab ${detailTab==='overview'?'active':''}" data-task-tab="overview">${icon('list')}Задача</button><button class="task-tab ${detailTab==='notes'?'active':''}" data-task-tab="notes">${icon('note')}Заметки <span>${t.notes.length}</span></button><span class="task-save-indicator"><span class="online-dot"></span>Сохранено</span></div><div class="task-dialog-body">${detailTab==='overview'?`<div class="task-overview"><div class="task-main-content"><div class="task-kicker">${badge(t)}<span>PT–${String(t.id).padStart(3,'0')}</span></div><textarea class="task-title-input" id="detail-title" aria-label="Название задачи" rows="1">${esc(t.title)}</textarea><section class="task-section"><div class="task-section-heading"><h3>Описание</h3><small>Выдели текст — появится форматирование</small></div>${richEditorHtml(t.description,'description')}</section><section class="task-section"><div class="task-section-heading"><h3>Чеклист</h3><small id="task-checklist-summary">${doneCount(t)} из ${t.checklist.length} · ${percent(t)}%</small></div><div class="checklist-progress"><div class="progress-track" id="task-checklist-progress" role="progressbar" aria-label="Прогресс чеклиста" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${percent(t)}"><div class="progress-fill ${percent(t)===100?'complete':''}" id="task-checklist-fill" style="width:${percent(t)}%"></div></div></div><div class="checklist-items">${t.checklist.map((c,i)=>`<div class="checklist-line ${c.done?'checked':''}"><button class="checkbox ${c.done?'checked':''}" role="checkbox" aria-checked="${c.done}" aria-label="${esc(c.text)}" data-check="${i}">${c.done?icon('check'):''}</button><span>${esc(c.text)}</span><button class="icon-btn remove-check" data-remove-check="${i}" aria-label="Удалить пункт">${icon('close')}</button></div>`).join('')}</div><button class="checklist-add" id="add-check">${icon('plus')}Добавить пункт</button></section><section class="task-section"><div class="task-section-heading"><h3>Заметки и документы</h3><small>${t.notes.length} ${ruDay(t.notes.length,['документ','документа','документов'])}</small></div>${t.notes.length?`<button class="task-note-preview" id="open-task-notes">${icon('note')}<span><strong>${esc(taskNoteTitle(t.notes[0]))}</strong><small>${taskWordCount(t.notes[0].text)} слов · открыть документ</small></span>${icon('chevron')}</button>`:`<button class="task-note-preview" id="open-task-notes">${icon('note')}<span><strong>Записать, пока помнишь</strong><small>Полноценный документ, без лимита на мысли</small></span>${icon('plus')}</button>`}</section></div><aside class="task-sidebar"><div class="task-deadline-card ${!t.due?'no-deadline':d<0?'deadline-late':''}">${icon(t.due?'clock':'calendar')}<h3>${deadlineTitle}</h3><p>${deadlineText}</p></div><div class="task-property"><label class="task-property-label" for="detail-status">Статус</label><select class="task-property-control" id="detail-status">${Object.entries(statusNames).map(([k,v])=>`<option value="${k}" ${t.status===k?'selected':''}>${v}</option>`).join('')}</select></div><div class="task-property"><label class="task-property-label" for="detail-date">Крайний срок</label><div class="task-date-control"><input class="task-property-control" type="date" id="detail-date" value="${t.due}" aria-label="Крайний срок">${t.due?`<button class="icon-btn" id="clear-due" aria-label="Убрать срок" title="Убрать срок">${icon('close')}</button>`:''}</div>${!t.due?'<span class="task-no-date-label">Срока нет</span>':''}</div><div class="task-property"><label class="task-property-label" for="detail-priority">Приоритет</label><select class="task-property-control" id="detail-priority"><option value="high" ${t.priority==='high'?'selected':''}>↗ Высокий</option><option value="normal" ${t.priority==='normal'?'selected':''}>→ Обычный</option><option value="low" ${t.priority==='low'?'selected':''}>↘ Низкий</option></select></div><div class="task-property"><label class="task-property-label" for="detail-project">Проект</label><select class="task-property-control" id="detail-project">${data.projects.map(p=>`<option value="${p.id}" ${p.id===t.project?'selected':''}>${esc(p.name)}</option>`).join('')}</select></div><div class="task-property"><span class="task-property-label">Создана</span><span class="task-created-date">${shortDate(t.created)}</span></div><div class="task-sidebar-footer task-cat-card">${catSvg('chaos','cat-art')}<span>«Там на пять минут».<br>Мяу, блядь, конечно.</span></div><button class="task-complete-button" id="detail-complete">${icon(t.status==='done'?'list':'check')}${t.status==='done'?'Вернуть в задачи':'Выполнено. Слава богу.'}</button></aside></div>`:notesWorkspaceHtml(t)}</div><div class="task-bottomline"><span>ESC — закрыть окно</span><span>Выделение → форматирование · ⌘ / Ctrl + B / I</span></div>`;
 $('#close-detail').onclick=closeTask;$('#expand-detail').onclick=()=>{flushDocument();taskFullscreen=!taskFullscreen;renderDetail()};$('#task-more').onclick=()=>{flushDocument();taskMoreModal(t)};
 $$('[data-task-tab]',el).forEach(b=>b.onclick=()=>{flushDocument();detailTab=b.dataset.taskTab;renderDetail()});
 if(detailTab==='overview')bindTaskOverview(t);else bindNotesWorkspace(t);
 $$('[data-editor-field]',el).forEach(bindDocumentEditor);
}
function bindTaskOverview(t){
 const title=$('#detail-title');title.style.height='auto';title.style.height=title.scrollHeight+'px';title.oninput=()=>{title.style.height='auto';title.style.height=title.scrollHeight+'px';if(title.value.trim()){t.title=title.value.trim();save()}};title.onblur=()=>{if(!title.value.trim())title.value=t.title;renderMain();renderNav()};
 $('#detail-status').onchange=e=>{flushDocument();changeStatus(t,e.target.value);save();render()};
 $('#detail-date').onchange=e=>{flushDocument();const hadDue=!!t.due;t.due=e.target.value;if(t.due){if(t.status==='deferred')t.status='created';if(!hadDue)recordEvent('deadline')}save();render()};
 $('#clear-due')?.addEventListener('click',()=>{flushDocument();t.due='';save();render()});
 $('#detail-priority').onchange=e=>{t.priority=e.target.value;save();renderMain()};$('#detail-project').onchange=e=>{flushDocument();t.project=e.target.value;save();render()};
 $$('[data-check]').forEach(b=>b.onclick=()=>{flushDocument();const item=t.checklist[b.dataset.check];item.done=!item.done;if(item.done){recordEvent('checked');if(item.wasUnchecked)recordEvent('rechecked')}else item.wasUnchecked=true;if(t.checklist.length>=5&&percent(t)===100)unlock('clean');save();evaluateAchievements();updateChecklistProgress(t);renderMain()});
 $$('[data-remove-check]').forEach(b=>b.onclick=()=>{flushDocument();t.checklist.splice(+b.dataset.removeCheck,1);save();render()});
 $('#add-check').onclick=()=>{flushDocument();inputModal('Декомпозиция подъехала','Что нужно сделать?','Ещё один пункт, и точно всё',value=>{t.checklist.push({text:value,done:false});save();render()},'Добавить пункт')};
 $('#open-task-notes').onclick=()=>{flushDocument();detailTab='notes';if(!t.notes.length)addTaskDocument(t);else renderDetail()};$('#detail-complete').onclick=()=>{flushDocument();completeTask(t.id)};
}
function updateChecklistProgress(t){
 const fill=$('#task-checklist-fill'),progress=$('#task-checklist-progress'),summary=$('#task-checklist-summary');
 if(fill){fill.style.width=percent(t)+'%';fill.classList.toggle('complete',percent(t)===100)}
 if(progress)progress.setAttribute('aria-valuenow',percent(t));
 if(summary)summary.textContent=`${doneCount(t)} из ${t.checklist.length} · ${percent(t)}%`;
 $$('[data-check]',$('#detail')).forEach(button=>{const item=t.checklist[+button.dataset.check];button.classList.toggle('checked',item.done);button.setAttribute('aria-checked',item.done);button.innerHTML=item.done?icon('check'):'';button.closest('.checklist-line').classList.toggle('checked',item.done)});
}
function notesWorkspaceHtml(t){
 const n=currentNote(t);if(n)selectedNoteId=n.id;
 return `<div class="notes-workspace"><aside class="notes-rail"><div class="notes-rail-header"><span>ДОКУМЕНТЫ</span><button class="icon-btn" id="add-document" aria-label="Новый документ">${icon('plus')}</button></div>${t.notes.map(note=>`<button class="note-document-item ${note.id===n?.id?'active':''}" data-note-id="${note.id}">${icon('note')}<span><strong>${esc(taskNoteTitle(note))}</strong><small>${taskWordCount(note.text)} слов · ${shortDate(note.date)}</small></span></button>`).join('')}${n?`<div class="document-outline"><span>В ЭТОМ ДОКУМЕНТЕ</span>${[...n.text.matchAll(/^(#{1,3})\s+(.+)$/gm)].map((m,i)=>`<button class="outline-item depth-${m[1].length}" data-outline="${i}">${esc(m[2])}</button>`).join('')||'<p>Добавь заголовки — появится оглавление.</p>'}</div>`:''}<div class="notes-rail-bottom"><img class="note-syngonium" src="assets/plant-syngonium.png" alt="Розовый сингониум">Память — так себе база данных.<br>Зато тут всё записано.</div></aside><div class="notes-document-pane">${n?`<div class="document-topline"><span class="document-meta">${icon('note')}Документ · <span id="document-word-count">${taskWordCount(n.text)}</span> слов</span><div class="document-controls"><button id="document-source-toggle" class="${noteSourceMode?'active':''}" aria-label="${noteSourceMode?'Визуальный редактор':'Исходный Markdown'}">${noteSourceMode?'↗ Редактор':'⌘ Markdown'}</button><button id="download-document" aria-label="Скачать Markdown" title="Скачать .md">↓ .md</button><button id="document-more" aria-label="Действия с документом">${icon('more')}</button></div></div><div class="document-scroll"><article class="document-paper">${richEditorHtml(n.text,'note',noteSourceMode)}</article></div><div class="document-bottomline"><span class="online-dot"></span><span id="document-save-status">Изменения сохранены</span><span>Выдели текст — остальное покажем</span></div>`:`<div class="task-empty-note">${catSvg('chaos','empty-cat')}<h2>Пока только в голове?</h2><p>Плохой план. После третьего созвона там останется белый шум.</p><button class="primary-btn" id="create-first-document">${icon('plus')}Создать документ</button></div>`}</div></div>`;
}
function addTaskDocument(t){flushDocument();const n={id:Date.now(),text:'# Новая заметка\n\n',date:today};t.notes.push(n);selectedNoteId=n.id;noteSourceMode=false;save();recordEvent('note');renderDetail();$('#note-editor')?.focus()}
function bindNotesWorkspace(t){
 $('#add-document').onclick=()=>addTaskDocument(t);$('#create-first-document')?.addEventListener('click',()=>addTaskDocument(t));
 $$('[data-note-id]').forEach(b=>b.onclick=()=>{flushDocument();selectedNoteId=+b.dataset.noteId;noteSourceMode=false;renderDetail()});
 const n=currentNote(t);if(!n)return;
 $('#document-source-toggle').onclick=()=>{flushDocument();noteSourceMode=!noteSourceMode;renderDetail()};
 $('#download-document').onclick=()=>{flushDocument();const a=document.createElement('a'),url=URL.createObjectURL(new Blob([n.text],{type:'text/markdown;charset=utf-8'}));a.href=url;a.download=taskNoteTitle(n).replace(/[/\\:*?"<>|]/g,'-')+'.md';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Документ выгружен. Теперь у хаоса есть файл.')};
 $('#document-more').onclick=()=>{flushDocument();showModal(modalHead('Этот документ')+`<p>${esc(taskNoteTitle(n))}</p><button class="modal-menu-button" id="duplicate-document">Сделать копию</button><button class="modal-menu-button" id="delete-document">Удалить документ</button>`);$('#duplicate-document').onclick=()=>{const copy={...n,id:Date.now(),text:n.text+'\n\n',date:today};t.notes.push(copy);selectedNoteId=copy.id;save();closeModal();renderDetail()};$('#delete-document').onclick=()=>{t.notes=t.notes.filter(x=>x.id!==n.id);selectedNoteId=t.notes[0]?.id??null;save();closeModal();renderDetail()}};
 $$('[data-outline]').forEach(b=>b.onclick=()=>{flushDocument();if(noteSourceMode){noteSourceMode=false;renderDetail()}const heading=$$('h1,h2,h3',$('#note-editor'))[+b.dataset.outline];heading?.scrollIntoView({behavior:'smooth',block:'start'})});
}
function saveDocumentEditor(editor){
 if(editor.dataset.dirty!=='true')return;
 const t=getTask(selectedId);if(!t)return;
 const value=editor.tagName==='TEXTAREA'?editor.value:htmlToMarkdown(editor),field=editor.dataset.editorField;
 if(field==='description'){if(value!==t.description){t.description=value;recordEvent('descriptionEdit')}}
 else{const note=currentNote(t);if(!note)return;note.text=value;const count=$('#document-word-count');if(count)count.textContent=taskWordCount(value);const rail=$(`[data-note-id="${note.id}"] strong`);if(rail)rail.textContent=taskNoteTitle(note)}
 editor.dataset.dirty='false';save();evaluateAchievements();const indicator=$('.task-save-indicator');if(indicator)indicator.innerHTML='<span class="online-dot"></span>Сохранено';const saved=$('#document-save-status');if(saved)saved.textContent='Изменения сохранены';
}
function bindDocumentEditor(editor){
 editor.dataset.dirty='false';
 editor.onfocus=()=>{documentEditor=editor};
 editor.oninput=()=>{editor.dataset.dirty='true';documentEditor=editor;const indicator=$('.task-save-indicator');if(indicator)indicator.textContent='Сохраняем…';clearTimeout(documentSaveTimer);documentSaveTimer=setTimeout(()=>saveDocumentEditor(editor),350)};
 editor.onkeydown=e=>{if((e.metaKey||e.ctrlKey)&&['b','i','k'].includes(e.key.toLowerCase())){e.preventDefault();captureDocumentSelection(editor);applyDocumentFormat({b:'bold',i:'italic',k:'link'}[e.key.toLowerCase()])}if(e.key==='Tab'&&editor.tagName==='TEXTAREA'){e.preventDefault();const start=editor.selectionStart;editor.setRangeText('  ',start,editor.selectionEnd,'end');editor.dispatchEvent(new Event('input'))}};
 editor.onmouseup=e=>{documentEditor=editor;captureDocumentSelection(editor,e)};editor.onkeyup=e=>captureDocumentSelection(editor,e);
 if(editor.isContentEditable)editor.onpaste=e=>{e.preventDefault();const text=e.clipboardData.getData('text/plain');document.execCommand('insertHTML',false,markdownToHtml(text));editor.dataset.dirty='true';saveDocumentEditor(editor)};
}
function captureDocumentSelection(editor,event){
 if(!editor||!editor.isConnected)return;
 let rect;
 if(editor.tagName==='TEXTAREA'){
  documentSourceSelection={start:editor.selectionStart,end:editor.selectionEnd};documentSelection=null;
  if(editor.selectionStart===editor.selectionEnd){hideSelectionToolbar();return}
  const bounds=editor.getBoundingClientRect();rect={left:event?.clientX||bounds.left+100,right:event?.clientX||bounds.left+100,top:event?.clientY||bounds.top+60};
 }else{
  const selection=window.getSelection();if(!selection||!selection.rangeCount||!editor.contains(selection.anchorNode)||!editor.contains(selection.focusNode)){documentSelection=null;documentSourceSelection=null;hideSelectionToolbar();return}
  documentSelection=selection.getRangeAt(0).cloneRange();documentSourceSelection=null;if(selection.isCollapsed){hideSelectionToolbar();return}rect=documentSelection.getBoundingClientRect();
 }
 documentEditor=editor;const toolbar=$('#selection-toolbar');toolbar.classList.remove('hidden');toolbar.style.left=Math.max(12,Math.min(innerWidth-toolbar.offsetWidth-12,(rect.left+rect.right)/2-toolbar.offsetWidth/2))+'px';toolbar.style.top=Math.max(12,rect.top-toolbar.offsetHeight-10)+'px';
}
function applyDocumentFormat(format){
 const editor=documentEditor;if(!editor||!editor.isConnected)return;
 if(format==='link'){const range=documentSelection?.cloneRange(),source=documentSourceSelection?{...documentSourceSelection}:null;inputModal('Ссылка на пруф','Адрес страницы','https://…',url=>{if(!/^https?:\/\/\S+$/i.test(url)){toast('Нужен адрес с https:// или http://');return}documentEditor=editor;documentSelection=range;documentSourceSelection=source;executeDocumentFormat('link',url)},'Вставить ссылку','url');hideSelectionToolbar();return}
 executeDocumentFormat(format);
}
function executeDocumentFormat(format,url){
 const editor=documentEditor;if(!editor?.isConnected)return;editor.focus();
 if(editor.tagName==='TEXTAREA'){
  const selection=documentSourceSelection||{start:editor.selectionStart,end:editor.selectionEnd},start=selection.start,end=selection.end,text=editor.value.slice(start,end)||'текст';let replacement=text;
  if(format==='bold')replacement='**'+text+'**';if(format==='italic')replacement='*'+text+'*';if(format==='strike')replacement='~~'+text+'~~';if(format==='h1')replacement='# '+text;if(format==='h2')replacement='## '+text;if(format==='list')replacement=text.split('\n').map(l=>'- '+l).join('\n');if(format==='quote')replacement=text.split('\n').map(l=>'> '+l).join('\n');if(format==='code')replacement='`'+text+'`';if(format==='link')replacement='['+text+']('+url+')';editor.setRangeText(replacement,start,end,'select');
 }else{
  const selection=window.getSelection();if(documentSelection){selection.removeAllRanges();selection.addRange(documentSelection)}
  const commands={bold:['bold'],italic:['italic'],strike:['strikeThrough'],h1:['formatBlock','h1'],h2:['formatBlock','h2'],list:['insertUnorderedList'],quote:['formatBlock','blockquote'],link:['createLink',url]};
  if(format==='code')document.execCommand('insertHTML',false,'<code>'+esc(selection.toString())+'</code>');else if(commands[format])document.execCommand(commands[format][0],false,commands[format][1]||null);
 }
 editor.dataset.dirty='true';if(format==='bold')recordEvent('bold');saveDocumentEditor(editor);if(format==='bold')unlock('markdown');hideSelectionToolbar();
}
document.addEventListener('selectionchange',()=>{const editor=document.activeElement?.closest?.('[data-editor-field]');if(editor?.isContentEditable)captureDocumentSelection(editor);else if(editor?.tagName==='TEXTAREA')captureDocumentSelection(editor);else if(!document.activeElement?.closest?.('#selection-toolbar,#modal-root'))hideSelectionToolbar()});
document.addEventListener('mousedown',e=>{if(e.target.closest('#selection-toolbar'))e.preventDefault();else if(!e.target.closest('[data-editor-field]'))hideSelectionToolbar()});
document.addEventListener('scroll',hideSelectionToolbar,true);
window.addEventListener('beforeunload',flushDocument);
