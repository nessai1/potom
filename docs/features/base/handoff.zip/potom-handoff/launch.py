"""Serve the portable Potom prototype on localhost. Python 3.8+."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

root = Path(__file__).resolve().parent / "prototype"
handler = partial(SimpleHTTPRequestHandler, directory=str(root))
try:
    with ThreadingHTTPServer(("127.0.0.1", 8765), handler) as server:
        print("Potom prototype: http://127.0.0.1:8765/", flush=True)
        print("Stop: Ctrl+C", flush=True)
        server.serve_forever()
except KeyboardInterrupt:
    print("Server stopped.")
except OSError as error:
    print("Cannot start local server:", error)
    print("Check whether port 8765 is already in use.")
    raise SystemExit(1)
