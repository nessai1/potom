потом. — макет и код
17 октября 2026

1. Распакуйте весь архив.
2. Откройте 01_START.html — это галерея макета и инструкция.
3. Полный код — папка prototype, сборка и npm не нужны.
4. Интерактивный запуск: Python 3, затем python3 launch.py (macOS)
   или py -3 launch.py (Windows). Адрес http://127.0.0.1:8765/

Внутри
01_START.html                Галерея и хендофф
screens/                     12 скриншотов 1440 × 1000
prototype/                   Полные HTML CSS JS и все ассеты
design/design-book.pdf       Дизайн макет и состояния
design/design-tokens.json    Цвета обеих тем, размеры, компоненты
design/achievements.json     26 достижений и варианты без мата
spec/technical-spec.html     ТЗ в редактируемом HTML
spec/technical-spec.pdf      ТЗ в PDF
spec/technical-spec.json     Структурированный текст ТЗ
MANIFEST.sha256              Контрольные суммы

Данные демонстрационные. Изменения сохраняются только в браузере.
Это UI прототип, не нативные установщики Windows/macOS.
Макет редактируется в коде; отдельного Figma/Sketch файла нет.
Google Fonts требует сеть, офлайн используется системный шрифт.
Коты и растения — фотореалистичные AI PNG, промпты внутри assets.
Лицензии Markdown библиотек сохранены в prototype/vendor.
Служебные файлы Sites, .git и данные браузера не включены.
